"""Export the animated Instant Combat pack to JSON (skinned-model format v2, like every Mossvale export).

  <model>.json                 model (every part = one bone, one bone per vertex), clips: idle walk auto attack death
                               (+ skill-<slug> for bosses, with 'skill' meta + events). Root bone carries the Y-up
                               conversion, so the file stands on its own (+Y up, +Z forward, feet at y = 0).
  <boss>-skill-<slug>-fx.json  telegraphs, markers and player dummies of one skill, clip 'skill', same frames and
                               same root conversion: play it together with the boss clip 'skill-<slug>'.
  index.json                   models, clips, skills (rules, fail penalties, numbers, events)

Usage: python3 export_ic_json.py <animated.blend> <out_dir> [--verify]
"""
import json, os, sys
import bpy
from mathutils import Matrix, Quaternion, Vector

SRC, OUT = [a for a in sys.argv[1:] if not a.startswith("--")][-2:]
VERIFY = "--verify" in sys.argv
os.makedirs(OUT, exist_ok=True)
C = Matrix(((1, 0, 0, 0), (0, 0, 1, 0), (0, -1, 0, 0), (0, 0, 0, 1)))
r5 = lambda x: round(x, 5) + 0.0
bpy.ops.wm.open_mainfile(filepath=SRC)
scene = bpy.context.scene
CONTACT = {"auto": [(15, "hit")], "attack": [(24, "hit")], "death": [(60, "dead")], "walk": [(0, "step"), (18, "step")]}


def trs(m, prev=None):
    t, q, s = m.decompose()
    if min(abs(s.x), abs(s.y), abs(s.z)) < 1e-6 or q.magnitude < 0.5:
        q = prev.copy() if prev is not None else Quaternion()
    if prev is not None and prev.dot(q) < 0:
        q.negate()
    return t, q, s


def walk(o, out):
    out.append(o)
    for c in sorted(o.children, key=lambda c: c.name):
        walk(c, out)
    return out


def geometry(objs, idx):
    materials, mi, meshes = [], {}, []
    for o in objs:
        if o.type != 'MESH' or not o.data.polygons:
            continue
        me = o.data
        me.calc_loop_triangles()
        col = me.color_attributes.get("CombatTint") or me.color_attributes[0]
        groups = {}
        for tri in me.loop_triangles:
            groups.setdefault(tri.material_index, []).append(tri)
        pos, nrm, colors, corner, subs = [], [], [], {}, []
        for mat_i, tris in sorted(groups.items()):
            m = me.materials[mat_i]
            if m.name not in mi:
                st = float(m.get("emission_strength", 1.6 if "emissive" in m.name else 0.0))
                mi[m.name] = len(materials)
                materials.append({"name": m.name, "vertex_color": True, "base_color": [1, 1, 1, 1], "emission_from_vertex_color": st > 0,
                                  "emission_color": [0, 0, 0], "emission_strength": st, "roughness": 0.67, "metallic": 0.1})
            ids = []
            for tri in tris:
                poly = me.polygons[tri.polygon_index]
                for vi, li in zip(tri.vertices, tri.loops):
                    k = (tri.polygon_index, vi)
                    if k not in corner:
                        corner[k] = len(pos) // 3
                        p = me.vertices[vi].co
                        pos += [r5(p.x), r5(p.y), r5(p.z)]
                        nrm += [r5(poly.normal.x), r5(poly.normal.y), r5(poly.normal.z)]
                        c = col.data[li].color if col.domain == 'CORNER' else col.data[vi].color
                        colors += [round(c[0], 4), round(c[1], 4), round(c[2], 4), 1.0]
                    ids.append(corner[k])
            subs.append({"material": mi[m.name], "indices": ids})
        meshes.append({"name": o.name, "vertex_count": len(pos) // 3, "positions": pos, "normals": nrm, "colors": colors,
                       "bone": [idx[o.name]] * (len(pos) // 3), "submeshes": subs})
    return materials, meshes


def skeleton(objs, idx, roots):
    sk = []
    for o in objs:
        t, q, s = trs(C if o in roots else o.matrix_parent_inverse @ o.matrix_basis)
        sk.append({"name": o.name, "parent": -1 if o in roots else idx[o.parent.name],
                   "rest": {"t": [r5(v) for v in t], "r": [r5(q.x), r5(q.y), r5(q.z), r5(q.w)], "s": [r5(v) for v in s]},
                   "inverse_bind": [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]})
    return sk


def sample(objs, roots, n):
    prev = [None] * len(objs)
    smp = [{"t": [], "r": [], "s": []} for _ in objs]
    for f in range(n + 1):
        scene.frame_set(f)
        for i, o in enumerate(objs):
            t, q, s = trs(C if o in roots else o.matrix_parent_inverse @ o.matrix_basis, prev[i])
            prev[i] = q
            smp[i]["t"].append([r5(v) for v in t]); smp[i]["r"].append([r5(q.x), r5(q.y), r5(q.z), r5(q.w)]); smp[i]["s"].append([r5(v) for v in s])
    tracks = []
    for i in range(len(objs)):
        tr = {"bone": i}
        for ch in ("t", "r", "s"):
            v = smp[i][ch]
            tr[ch] = [v[0]] if all(max(abs(x - y) for x, y in zip(a, v[0])) < 1e-5 for a in v) else v
        tracks.append(tr)
    return tracks


def verify(objs, meshes, sk, tracks, root, n):
    worst = 0.0
    R = root.matrix_world.inverted()
    for f in (0, n // 2, n):
        world = []
        for i, b in enumerate(sk):
            tr = tracks[i]
            g = lambda ch: tr[ch][0] if len(tr[ch]) == 1 else tr[ch][f]
            t, r, s = g("t"), g("r"), g("s")
            L = Matrix.Translation(t) @ Quaternion((r[3], r[0], r[1], r[2])).to_matrix().to_4x4() @ Matrix.Diagonal((*s, 1))
            world.append(L if b["parent"] < 0 else world[b["parent"]] @ L)
        scene.frame_set(f)
        for m in meshes:
            o = bpy.data.objects[m["name"]]
            P = m["positions"]
            for vi in range(0, m["vertex_count"], 7):
                v = Vector(P[vi * 3:vi * 3 + 3])
                worst = max(worst, (world[m["bone"][0]] @ v - C @ R @ o.matrix_world @ v).length)
    return worst


def clip_actions(parts, clip):
    """drive every part with its action of this clip (the NLA tracks stay muted)"""
    for o in parts:
        tr = o.animation_data.nla_tracks.get(clip)
        o.animation_data.action = tr.strips[0].action if tr else None
        if tr:
            o.animation_data.action_slot = o.animation_data.action.slots[0]


catalog = json.loads(scene.get("skill_catalog", "{}"))
index = {"fps": 30, "models": {}, "skills": catalog, "ranged_auto": json.loads(scene.get("ranged_auto", "{}"))}
worst_all = 0.0
roots = sorted([o for o in bpy.data.objects if o.parent is None and o.type == 'EMPTY' and not o.name.startswith("fx-") and "axes" in o], key=lambda o: o.name)
for root in roots:
    objs = walk(root, [])
    idx = {o.name: i for i, o in enumerate(objs)}
    parts = objs[1:]
    materials, meshes = geometry(objs, idx)
    sk = skeleton(objs, idx, [root])
    clips = [tr.name for tr in parts[0].animation_data.nla_tracks]
    anims = {}
    for clip in clips:
        short = clip[len(root.name) + 1:]
        clip_actions(parts, clip)
        n = int(parts[0].animation_data.action.frame_range[1])
        tracks = sample(objs, [root], n)
        a = {"frames": n + 1, "duration": n / 30, "loop": short in ("idle", "walk"), "events": [{"frame": f, "time": round(f / 30, 3), "name": e} for f, e in CONTACT.get(short, [])], "tracks": tracks}
        fx = next((o for o in bpy.data.objects if o.name.startswith("fx-") and o.parent is None and o.get("boss") == root.name and o.get("clip") == short), None)
        if fx:
            a["skill"] = json.loads(fx["skill"])
            a["events"] = json.loads(fx["events"])
            a["fx_file"] = f"{root.name}-{short}-fx.json"
            a["ranged"] = short == "auto"
        if VERIFY:
            worst_all = max(worst_all, verify(objs, meshes, sk, tracks, root, n))
        anims[short] = a
    for o in parts:
        o.animation_data.action = None
    doc = {"format": "horned_apostle.skinned_model", "version": 2, "source": "Mossvale Instant Combat (animated)",
           "coordinate_system": {"up": "+Y", "forward": "+Z", "handedness": "right", "units": "meters"}, "fps": 30,
           "materials": materials, "skeleton": sk, "meshes": meshes, "animations": anims}
    with open(os.path.join(OUT, f"{root.name}.json"), "w") as fh:
        json.dump(doc, fh, separators=(",", ":"))
    index["models"][root.name] = {"file": f"{root.name}.json", "clips": {k: v["frames"] for k, v in anims.items()},
                                  "vertices": sum(m["vertex_count"] for m in meshes)}
    print(root.name, len(anims), "clips", os.path.getsize(os.path.join(OUT, f"{root.name}.json")) // 1024, "KB")
    # skill fx files
    for fx in sorted([o for o in bpy.data.objects if o.name.startswith(f"fx-{root.name}-") and o.parent is None], key=lambda o: o.name):
        fobjs = walk(fx, [])
        fidx = {o.name: i for i, o in enumerate(fobjs)}
        fm, fmesh = geometry(fobjs, fidx)
        fsk = skeleton(fobjs, fidx, [fx])
        n = int(fx["frames"])
        ftr = sample(fobjs, [fx], n)
        if VERIFY:
            worst_all = max(worst_all, verify(fobjs, fmesh, fsk, ftr, fx, n))
        clipname = fx["clip"]
        fdoc = {"format": "horned_apostle.skinned_model", "version": 2, "source": "Mossvale Instant Combat skill telegraphs",
                "coordinate_system": {"up": "+Y", "forward": "+Z", "handedness": "right", "units": "meters"}, "fps": 30,
                "boss": root.name, "boss_clip": clipname, "materials": fm, "skeleton": fsk, "meshes": fmesh,
                "animations": {"skill": {"frames": n + 1, "duration": n / 30, "loop": False, "events": json.loads(fx["events"]),
                                         "skill": json.loads(fx["skill"]), "tracks": ftr}}}
        with open(os.path.join(OUT, f"{root.name}-{clipname}-fx.json"), "w") as fh:
            json.dump(fdoc, fh, separators=(",", ":"))
with open(os.path.join(OUT, "index.json"), "w") as fh:
    json.dump(index, fh, indent=1)
if VERIFY:
    assert worst_all < 2e-3, worst_all
    print(f"verify max {worst_all * 1000:.3f} mm OK")
