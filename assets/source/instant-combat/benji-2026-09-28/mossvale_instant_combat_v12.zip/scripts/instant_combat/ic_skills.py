"""Instant Combat boss skills: 3 rule skills per boss (boss clip + telegraphs + player dummies that show the rule).

Every skill writes
  - the boss clip '<boss>-skill-<slug>' (NLA track on every part, like the base clips)
  - an fx root 'fx-<boss>-<slug>' in the collection 'Skill FX' at the boss position with the telegraphs, markers,
    cages, beams and blue player dummies. Dummies that follow the rule survive; the red-flagged one breaks it and
    gets punished, so the viewer shows both the rule and the penalty.
  - custom props on the fx root: skill (JSON: name, rule, fail, numbers), events (JSON), frames.
Coordinates are boss-relative: forward = -Y, metres, ground z = 0.
"""
import json
import math
import random

import bpy
import bmesh
from mathutils import Euler, Matrix, Vector

from ic_motion import TAU, Track, ease

FXC = None
C = dict(danger="#ff3b30", danger2="#ff8a3d", dark="#2a0a10", safe="#ffd24a", good="#6bff8f", void="#a86bff",
         void2="#5b2bd6", acid="#9dff3b", acid2="#3f8f1a", player="#4f86ff", skin="#ffd2a8", bone="#efe4c8",
         white="#ffffff", night="#0b0714", gold="#ffb22e", blue="#58a6ff", pink="#ff5fa2", web="#e9e2ff")


def hx(h):
    return tuple(int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))


def mat(name, strength):
    m = bpy.data.materials.get(name)
    if m:
        return m
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    vc = m.node_tree.nodes.new("ShaderNodeVertexColor")
    vc.layer_name = "CombatTint"
    m.node_tree.links.new(vc.outputs["Color"], b.inputs["Base Color"])
    b.inputs["Roughness"].default_value = 0.7
    if strength:
        m.node_tree.links.new(vc.outputs["Color"], b.inputs["Emission Color"])
        b.inputs["Emission Strength"].default_value = strength
    m["emission_strength"] = strength
    return m


class M:
    def __init__(self):
        self.bm = bmesh.new()
        self.cid = self.bm.faces.layers.int.new("cid")
        self.cols = []

    def _tag(self, faces, col):
        self.cols.append(hx(col) if isinstance(col, str) else col)
        for f in faces:
            f[self.cid] = len(self.cols) - 1

    def box(self, c, s, col, rot=(0, 0, 0)):
        g = bmesh.ops.create_cube(self.bm, size=1.0)
        R = Euler(rot).to_matrix().to_4x4()
        bmesh.ops.transform(self.bm, matrix=Matrix.Translation(Vector(c)) @ R @ Matrix.Diagonal((*s, 1)), verts=g["verts"])
        self._tag({f for v in g["verts"] for f in v.link_faces}, col)
        return self

    def fan(self, pts, col, z=0.03):
        """convex flat polygon"""
        vs = [self.bm.verts.new((p[0], p[1], z)) for p in pts]
        self._tag([self.bm.faces.new(vs)], col)
        return self

    def band(self, inner, outer, col, z=0.03):
        """quad strip between two point lists (rings, arcs)"""
        a = [self.bm.verts.new((p[0], p[1], z)) for p in inner]
        b = [self.bm.verts.new((p[0], p[1], z)) for p in outer]
        faces = [self.bm.faces.new((a[i], b[i], b[i + 1], a[i + 1])) for i in range(len(a) - 1)]
        self._tag(faces, col)
        return self

    def obj(self, name, parent, loc=(0, 0, 0), glow=1.6):
        me = bpy.data.meshes.new(name)
        self.bm.to_mesh(me)
        self.bm.free()
        me.materials.append(mat("Instant Combat telegraph", 1.6) if glow else mat("Instant Combat fx solid", 0.0))
        ids = me.attributes["cid"].data
        at = me.color_attributes.new("CombatTint", 'BYTE_COLOR', 'CORNER')
        me.color_attributes.active_color = at
        for p in me.polygons:
            c = self.cols[ids[p.index].value]
            for li in p.loop_indices:
                at.data[li].color_srgb = (*c, 1)
        me.attributes.remove(me.attributes["cid"])
        o = bpy.data.objects.new(name, me)
        FXC.objects.link(o)
        o.parent = parent
        o.location = loc
        return o


def arc(r, a0, a1, n):
    """points on a circle; angle 0 = front (-Y), positive = clockwise seen from above (towards +X)"""
    return [(r * math.sin(a0 + (a1 - a0) * i / n), -r * math.cos(a0 + (a1 - a0) * i / n)) for i in range(n + 1)]


def disk(r, col, n=40):
    return M().fan(arc(r, 0, TAU, n)[:-1], col)


def ring(r0, r1, col, n=48, a0=0.0, a1=TAU):
    return M().band(arc(r0, a0, a1, n), arc(r1, a0, a1, n), col)


def sector(r, center, width, col, n=32, r0=0.0):
    a0, a1 = center - width / 2, center + width / 2
    if r0 <= 0:
        return M().fan([(0, 0)] + arc(r, a0, a1, n), col)
    return M().band(arc(r0, a0, a1, n), arc(r, a0, a1, n), col)


def lane(length, width, col, start=0.0):
    return M().fan([(-width / 2, -start), (width / 2, -start), (width / 2, -start - length), (-width / 2, -start - length)], col)


def anim(o, n, fn):
    o.rotation_mode = 'XYZ'
    o.animation_data_create()
    act = bpy.data.actions.new(o.name)
    o.animation_data.action = act
    vals = []
    for f in range(n + 1):
        loc, rot, s = fn(f)
        s = (s, s, s) if isinstance(s, (int, float)) else s
        vals.append((Vector(loc), rot, s))
    for path, idx in (("location", 0), ("rotation_euler", 1), ("scale", 2)):
        for i in range(3):
            fc = act.fcurve_ensure_for_datablock(o, path, index=i)
            fc.keyframe_points.add(n + 1)
            fc.keyframe_points.foreach_set("co", [x for f in range(n + 1) for x in (f, vals[f][idx][i])])
            for kp in fc.keyframe_points:
                kp.interpolation = 'LINEAR'
            fc.update()


def tele(f, on, hit, off=None, pulse=0.03):
    """telegraph scale: grows in, pulses, vanishes after the hit"""
    off = off if off is not None else hit + 6
    if f < on:
        return 0.001
    if f < on + 6:
        return max(0.001, ease("out", (f - on) / 6))
    if f <= hit:
        return 1 + pulse * math.sin(f * 0.9)
    if f < off:
        return max(0.001, 1 - (f - hit) / (off - hit))
    return 0.001


def pop(f, at, dur=8, grow=0.25):
    """impact flash: appears at 'at', grows a bit and disappears"""
    if f < at or f >= at + dur:
        return 0.001
    u = (f - at) / dur
    return 1 + grow * u


def place(o, n, pos, scale_fn, z=0.0, rot=(0, 0, 0)):
    anim(o, n, lambda f: ((pos[0], pos[1], z), rot, scale_fn(f)))
    return o


# ------------------------------------------------------------------ player dummies
def path_at(path, f):
    """path: [(frame, (x, y))] -> smoothly interpolated position"""
    if f <= path[0][0]:
        return Vector(path[0][1])
    for (f0, a), (f1, b) in zip(path, path[1:]):
        if f <= f1:
            u = ease("io", (f - f0) / (f1 - f0) if f1 > f0 else 1)
            return Vector(a).lerp(Vector(b), u)
    return Vector(path[-1][1])


def dummy(ctx, name, path, hit=None, hit_kind="launch", fail=False):
    """blue voxel player: walks the path, faces the boss, bobs when moving; 'hit' frame -> launched and knocked down"""
    m = M()
    col = C["player"]
    m.box((-0.13, 0, 0.42), (0.18, 0.2, 0.84), "#2c3f7a").box((0.13, 0, 0.42), (0.18, 0.2, 0.84), "#2c3f7a")
    m.box((0, 0, 1.12), (0.52, 0.3, 0.6), col).box((-0.34, 0, 1.1), (0.14, 0.16, 0.58), col).box((0.34, 0, 1.1), (0.14, 0.16, 0.58), col)
    m.box((0, 0, 1.62), (0.42, 0.38, 0.4), C["skin"]).box((0, -0.2, 1.64), (0.26, 0.02, 0.08), "#1a1a2a")
    if fail:
        m.box((0, 0, 2.05), (0.12, 0.12, 0.12), C["danger"], (0.7, 0.7, 0))
    o = m.obj(f"{ctx['prefix']}-{name}", ctx["root"], glow=0)
    n = ctx["n"]

    def fn(f):
        p = path_at(path, f)
        q = path_at(path, f + 2)
        moving = (q - p).length > 0.02
        d = -p if p.length > 0.01 else Vector((0, 1))
        yaw = math.atan2(d.x, -d.y)
        z = 0.06 * abs(math.sin(f * 0.55)) if moving else 0.0
        rx = 0.0
        if hit is not None and f >= hit:
            u = min(1.0, (f - hit) / 14)
            away = p.normalized() if p.length > 0.01 else Vector((0, 1))
            if hit_kind == "launch":
                p = p + away * 3.2 * ease("out", u)
                z = 1.6 * math.sin(math.pi * u)
                rx = -1.45 * ease("io", u)
            elif hit_kind == "crush":
                z = 0
                rx = -1.5 * ease("in", u)
            elif hit_kind == "rooted":
                z = 0
                rx = 0.25 * math.sin(f * 0.7)
            else:
                rx = -1.45 * ease("io", u)
        return (p.x, p.y, z), (rx, 0, yaw), 1.0
    anim(o, n, fn)
    return o


def marker(ctx, name, parent_dummy, col, on, off, shape="diamond", size=1.0):
    m = M()
    if shape == "diamond":
        m.box((0, 0, 0), (0.34 * size, 0.34 * size, 0.34 * size), col, (0.62, 0.62, 0))
    elif shape == "note":
        m.box((0, 0, 0), (0.26, 0.1, 0.26), col).box((0.12, 0, 0.3), (0.06, 0.06, 0.5), col)
    else:
        m.box((0, 0, 0), (0.5 * size, 0.08, 0.5 * size), col)
    o = m.obj(f"{ctx['prefix']}-{name}", parent_dummy)
    anim(o, ctx["n"], lambda f: ((0, 0, 2.45 + 0.08 * math.sin(f * 0.3)), (0, 0, f * 0.12), tele(f, on, off, off + 4, 0.08)))
    return o


# ------------------------------------------------------------------ boss clip + skill registry
def run_skill(R, scene, slug, spec):
    """spec(ctx) must return dict(n, keys, meta, events); it builds its fx under ctx['root']"""
    key = R.key
    fxroot = bpy.data.objects.new(f"fx-{key}-{slug}", None)
    FXC.objects.link(fxroot)
    fxroot.location = R.root.location
    fxroot.empty_display_size = 1.0
    ctx = {"root": fxroot, "prefix": f"fx-{key}-{slug}", "R": R, "rng": random.Random(len(key) * 31 + len(slug))}
    ctx["n"] = spec.__defaults__[0] if spec.__defaults__ else 120
    out = spec(ctx)
    K = Track(out["keys"])
    n = ctx["n"]
    R.bake(f"{key}-skill-{slug}", n, lambda f: R.pose(K, f, n, False, life=0.8, gait_cycles=out.get("gait_cycles", 0),
                                                      gait_amp=None), False, keep_air=True)
    meta = dict(out["meta"], clip=f"{key}-skill-{slug}", frames=n + 1, seconds=round(n / 30, 2))
    fxroot["skill"] = json.dumps(meta)
    fxroot["events"] = json.dumps([{"frame": fr, "time": round(fr / 30, 3), "name": nm} for fr, nm in out["events"]])
    fxroot["boss"] = key
    fxroot["frames"] = n
    fxroot["clip"] = f"skill-{slug}"
    return meta


# ================================================================== BONE PIT
def tyrant_verdict(ctx, n=110):
    r = ctx["root"]
    place(sector(14, 0, math.pi, C["danger"]).obj(f"{ctx['prefix']}-front-half", r), n, (0, 0), lambda f: tele(f, 12, 58))
    place(sector(14.2, math.pi, math.pi, C["safe"], r0=13.6).obj(f"{ctx['prefix']}-safe-edge", r), n, (0, 0), lambda f: tele(f, 12, 58, 70, 0))
    place(ring(1.0, 2.2, C["white"]).obj(f"{ctx['prefix']}-shockwave", r), n, (0, -3.5), lambda f: pop(f, 58, 16, 5.0))
    for i, a in enumerate((-0.5, 0.0, 0.5)):
        dummy(ctx, f"player{i}", [(0, (6 * math.sin(a), -7 * math.cos(a))), (16, (6 * math.sin(a), -7 * math.cos(a))),
                                  (46, (7 * math.sin(a + 2.6 * (1 if a >= 0 else -1)), -7 * math.cos(a + 2.6 * (1 if a >= 0 else -1))))])
    dummy(ctx, "greedy", [(0, (1.5, -6)), (58, (1.5, -6))], hit=58, fail=True)
    return dict(keys=[(0, {}), (18, {"armR.rx": -2.2, "body.rx": -0.2, "body.z": 0.15, "head.rx": -0.25, "stance": 0.12}),
                      (40, {"armR.rx": -2.3, "body.rx": -0.24, "body.z": 0.18, "head.rx": -0.3, "tremor": 0.8, "stance": 0.12}),
                      (58, {"armR.rx": 0.75, "body.rx": 0.34, "body.z": -0.35, "head.rx": 0.28, "stance": 0.3}, "out"),
                      (72, {"armR.rx": 0.7, "body.rx": 0.3, "body.z": -0.3, "head.rx": 0.2, "stance": 0.3}),
                      (110, {}, "io")],
                events=[(12, "telegraph"), (58, "slam")],
                meta=dict(name="Verdict of Bones", rule="Get BEHIND the Tyrant. The whole front half (14 m) is crushed when the tablet lands.",
                          fail="85% max HP + knocked down 2 s", telegraph_s=1.5, shape="half circle, front, 14 m"))


def tyrant_cage(ctx, n=130):
    r = ctx["root"]
    caged = [(-4.5, -6.0), (5.0, -5.0)]
    helpers = [[(0, (0, -8)), (45, (-3.3, -6.8)), (95, (-3.3, -6.8))], [(0, (2, -9)), (45, (6.2, -6.0)), (110, (6.2, -6.0))],
               [(0, (-2, -9)), (48, (-5.6, -4.6)), (95, (-5.6, -4.6)), (115, (3.9, -4.2))]]
    for i, p in enumerate(caged):
        d = dummy(ctx, f"caged{i}", [(0, p), (130, p)])
        marker(ctx, f"mark{i}", d, C["danger"], 12, 40)
        cg = M()
        for k in range(10):
            a = k * TAU / 10
            cg.box((0.85 * math.sin(a), -0.85 * math.cos(a), 1.1), (0.16, 0.16, 2.3), C["bone"], (0, 0, -a))
        cg.box((0, 0, 2.3), (1.9, 1.9, 0.18), C["bone"])
        brk = 95 if i == 0 else 112
        o = cg.obj(f"{ctx['prefix']}-cage{i}", r, glow=0)
        anim(o, n, lambda f, p=p, brk=brk: ((p[0], p[1], min(0, -2.4 + 2.4 * ease("out", (f - 40) / 8)) if f >= 40 else -2.4),
                                               (0, 0, 0.05 * math.sin(f * 1.7) if 50 < f < brk else 0), 1.0 if f < brk else 0.001))
        place(ring(1.25, 1.45, C["danger"]).obj(f"{ctx['prefix']}-timer{i}", r), n, p,
              lambda f, brk=brk: 0.001 if f < 40 or f >= brk else 1.0 - 0.5 * (f - 40) / 90)
        place(disk(1.6, C["bone"], 12).obj(f"{ctx['prefix']}-shards{i}", r), n, p, lambda f, brk=brk: pop(f, brk, 10, 1.2), z=1.0)
    for i, pth in enumerate(helpers):
        dummy(ctx, f"helper{i}", pth)
    return dict(keys=[(0, {}), (14, {"armR.rx": -0.6, "body.ry": 0.18, "head.rz": 0.3}), (26, {"armR.rx": -0.5, "body.ry": -0.18, "head.rz": -0.35}),
                      (34, {"legR.rx": -0.55, "legR.z": 0.35, "body.rx": -0.1}), (40, {"legR.rx": 0.05, "body.z": -0.25, "body.rx": 0.12, "tremor": 0.5}, "out"),
                      (60, {}), (130, {})],
                events=[(12, "mark"), (40, "cages"), (95, "cage_broken"), (112, "cage_broken")],
                meta=dict(name="Bone Cage", rule="Two players are caged. Everyone else must break both cages (each has HP) within 8 s.",
                          fail="A cage still standing after 8 s kills the player inside", cages=2, cage_hp_pct_of_boss=2, timer_s=8))


def tyrant_toll(ctx, n=140):
    r = ctx["root"]
    target = (0.0, -8.0)
    place(disk(3.2, C["safe"]).obj(f"{ctx['prefix']}-toll-circle", r), n, target, lambda f: tele(f, 14, 120, 128, 0.02))
    for i, t in enumerate((58, 84, 110)):
        place(ring(3.1, 3.5, C["gold"]).obj(f"{ctx['prefix']}-toll{i}", r), n, target, lambda f, t=t: pop(f, t, 10, 1.4))
        place(ring(0.5, 1.5, C["danger"]).obj(f"{ctx['prefix']}-lonely{i}", r), n, (8.5, -3.0), lambda f, t=t: pop(f, t, 8, 0.6))
    for i, (x, y) in enumerate(((-6, -5), (6, -6), (-3, -11), (3, -11))):
        dummy(ctx, f"player{i}", [(0, (x, y)), (18, (x, y)), (48, (target[0] + 0.9 * math.cos(i * 1.6), target[1] + 0.9 * math.sin(i * 1.6)))])
    dummy(ctx, "loner", [(0, (8.5, -3.0)), (140, (8.5, -3.0))], hit=110, fail=True)
    ks = [(0, {}), (20, {"armR.rx": -1.3, "body.rx": -0.12, "head.rx": -0.2})]
    for t in (58, 84, 110):
        ks += [(t - 8, {"armR.rx": -1.5, "body.rx": -0.16, "head.rx": -0.25}), (t, {"armR.rx": 0.45, "body.rx": 0.2, "body.z": -0.2, "head.rx": 0.15, "tremor": 0.4}, "out")]
    ks += [(140, {})]
    return dict(keys=ks, events=[(14, "mark"), (58, "toll"), (84, "toll"), (110, "toll")],
                meta=dict(name="Grave Toll", rule="Stack in the gold circle. Each of the 3 tolls is split between everyone inside.",
                          fail="Alone: 3 x 60% max HP. Fewer than 3 players inside: 3 x 40%", tolls=3, radius_m=3.2))


def colossus_split(ctx, n=120):
    r = ctx["root"]
    for wave, (on, hit, rot) in enumerate(((12, 42, 0.0), (58, 86, math.pi / 4))):
        for k in range(4):
            o = lane(16, 2.6, C["danger"], start=1.5).obj(f"{ctx['prefix']}-fissure{wave}{k}", r)
            place(o, n, (0, 0), lambda f, on=on, hit=hit: tele(f, on, hit, hit + 10), rot=(0, 0, rot + k * math.pi / 2))
            o2 = lane(16, 0.5, C["danger2"], start=1.5).obj(f"{ctx['prefix']}-crack{wave}{k}", r)
            place(o2, n, (0, 0), lambda f, hit=hit: pop(f, hit, 16, 0.0), z=0.05, rot=(0, 0, rot + k * math.pi / 2))
    for i in range(3):
        a0 = math.pi / 4 + i * math.pi / 2
        dummy(ctx, f"player{i}", [(0, (6 * math.sin(a0), -6 * math.cos(a0))), (44, (6 * math.sin(a0), -6 * math.cos(a0))),
                                  (70, (6 * math.sin(a0 + math.pi / 4), -6 * math.cos(a0 + math.pi / 4)))])
    dummy(ctx, "slow", [(0, (0.3, -7)), (86, (0.3, -7))], hit=42, fail=True)
    up = {"armL.rx": -2.8, "armR.rx": -2.8, "body.rx": -0.22, "body.z": 0.12, "head.rx": -0.25}
    dn = {"armL.rx": 0.5, "armR.rx": 0.5, "body.rx": 0.36, "body.z": -0.35, "head.rx": 0.25, "stance": 0.25}
    return dict(keys=[(0, {}), (22, up), (34, dict(up, tremor=0.6)), (42, dn, "out"), (52, dict(dn, **{"body.rx": 0.3})),
                      (68, up), (78, dict(up, tremor=0.6)), (86, dn, "out"), (96, dict(dn, **{"body.rx": 0.3})), (120, {})],
                events=[(12, "telegraph"), (42, "slam"), (58, "telegraph"), (86, "slam")],
                meta=dict(name="Earthsplitter", rule="Stand between the 4 fissure lines, then move again: the second slam is turned 45 degrees.",
                          fail="60% max HP + bleeding 5%/s for 6 s", lanes=4, lane_width_m=2.6, length_m=16))


def colossus_quake(ctx, n=110):
    r = ctx["root"]
    place(ring(8, 18, C["danger"]).obj(f"{ctx['prefix']}-outer", r), n, (0, 0), lambda f: tele(f, 10, 62))
    place(ring(7.7, 8.0, C["safe"]).obj(f"{ctx['prefix']}-safe-edge", r), n, (0, 0), lambda f: tele(f, 10, 62, 72, 0))
    place(ring(2, 3, C["white"]).obj(f"{ctx['prefix']}-shock", r), n, (0, 0), lambda f: pop(f, 62, 16, 5.0))
    for i, a in enumerate((-1.0, 0.2, 1.4)):
        dummy(ctx, f"player{i}", [(0, (12 * math.sin(a), -12 * math.cos(a))), (14, (12 * math.sin(a), -12 * math.cos(a))),
                                  (52, (5.5 * math.sin(a), -5.5 * math.cos(a)))])
    dummy(ctx, "far", [(0, (-9, 10)), (62, (-9, 10))], hit=62, fail=True)
    return dict(keys=[(0, {}), (16, {"body.z": -0.5, "armL.rx": 0.7, "armR.rx": 0.7, "body.rx": 0.2, "stance": 0.3}),
                      (28, {"body.z": 2.4, "armL.rx": -2.4, "armR.rx": -2.4, "body.rx": -0.15}, "out"),
                      (46, {"body.z": 2.8, "armL.rx": -2.6, "armR.rx": -2.6, "body.rx": -0.1}),
                      (62, {"body.z": -0.45, "armL.rx": 0.6, "armR.rx": 0.6, "body.rx": 0.3, "stance": 0.35, "tremor": 0.7}, "in"),
                      (78, {"body.z": -0.3, "armL.rx": 0.4, "armR.rx": 0.4, "body.rx": 0.2, "stance": 0.3}), (110, {})],
                events=[(10, "telegraph"), (28, "jump"), (62, "land")],
                meta=dict(name="Marrow Quake", rule="Run CLOSE to the Colossus (inside 8 m) before it lands. Everything outside is hit.",
                          fail="70% max HP + knocked up 2 s", safe_radius_m=8, hit_radius_m=18))


def colossus_grip(ctx, n=130):
    r = ctx["root"]
    victim = [(0, (0.8, -4.2)), (22, (0.8, -4.2)), (30, (1.6, -3.0))]
    d = dummy(ctx, "grabbed", victim)
    g = M().box((0, 0, 0), (0.7, 0.7, 0.7), C["pink"], (0.6, 0.6, 0))
    place(g.obj(f"{ctx['prefix']}-weak-spot", r), n, (1.6, -3.0), lambda f: (0.001 if f < 30 or f > 98 else 1 + 0.25 * math.sin(f * 0.6)), z=3.4)
    place(ring(1.3, 1.6, C["danger"]).obj(f"{ctx['prefix']}-timer", r), n, (1.6, -3.0), lambda f: 0.001 if f < 30 or f > 98 else 1 - 0.6 * (f - 30) / 68, z=0.05)
    for i, (x, y) in enumerate(((-3, -7), (4, -7), (0, -9))):
        dummy(ctx, f"helper{i}", [(0, (x, y)), (30, (x, y)), (48, (1.6 + 1.6 * math.sin(i * 2.1), -3.0 - 1.6 * math.cos(i * 2.1)))])
    # the grabbed dummy: override with a lifted path
    def lifted(f):
        p = path_at(victim, f)
        z = 0.0
        if 30 <= f < 98:
            z = 2.6 + 0.12 * math.sin(f * 1.3)
        elif 98 <= f < 108:
            z = 2.6 * (1 - ease("in", (f - 98) / 10))
        return (p.x, p.y, z), (0.2 * math.sin(f * 1.1) if 30 <= f < 98 else 0, 0, 0), 1.0
    d.animation_data.action = None
    anim(d, n, lifted)
    return dict(keys=[(0, {}), (20, {"armR.rx": -1.6, "body.rx": 0.2, "body.ry": 0.15, "head.rx": 0.2}, "out"),
                      (30, {"armR.rx": -1.15, "armR.rz": 0.2, "body.rx": 0.1}), (60, {"armR.rx": -1.25, "armR.rz": 0.2, "tremor": 0.5}),
                      (96, {"armR.rx": -1.2, "armR.rz": 0.2, "tremor": 0.9}), (104, {"armR.rx": -0.6, "body.rx": -0.1, "head.rx": -0.3}, "out"),
                      (130, {})],
                events=[(20, "grab"), (30, "weak_spot"), (98, "released")],
                meta=dict(name="Crushing Grip", rule="The Colossus grabs its target. Hit the glowing pink fist for 5% of its HP within 4 s to free them.",
                          fail="The grabbed player is crushed (dies)", weak_spot_pct=5, timer_s=4))


def cantor_requiem(ctx, n=130):
    r = ctx["root"]
    red = M()
    for k in range(16):
        a = k * TAU / 16
        red.box((2.6 * math.sin(a), 0, 2.6 * math.cos(a)), (0.35, 0.2, 0.35), C["danger"], (0, a, 0))
    place(red.obj(f"{ctx['prefix']}-red-halo", r), n, (0, 0.4), lambda f: 0.001 if f < 30 or f > 92 else 1 + 0.08 * math.sin(f * 0.8), z=6.2)
    place(disk(17, C["dark"], 48).obj(f"{ctx['prefix']}-silence", r), n, (0, 0), lambda f: 0.001 if f < 30 or f > 92 else 1.0, z=0.02)
    for i, (x, y) in enumerate(((-5, -6), (4, -7), (0, -10))):
        dummy(ctx, f"player{i}", [(0, (x, y)), (24, (x + 1, y + 1)), (30, (x + 1, y + 1)), (92, (x + 1, y + 1)), (120, (x, y))])
    run = [(0, (-8, -2)), (130, (6, -12))]
    dummy(ctx, "runner", run, hit=62, hit_kind="fall", fail=True)
    bolt = M().box((0, 0, 6), (0.5, 0.5, 12), C["danger"]).box((0, 0, 6), (0.2, 0.2, 12), C["white"])
    b = bolt.obj(f"{ctx['prefix']}-bolt", r)
    anim(b, n, lambda f: (tuple(path_at(run, 62)) + (0,), (0, 0, 0), pop(f, 62, 8, 0.0)))
    return dict(keys=[(0, {"halo.spin": 0}), (20, {"armR.rx": -0.75, "armR.rz": -0.12, "head.rx": -0.4, "body.rx": -0.15, "halo.s": 0.25, "halo.spin": 3}),
                      (30, {"armR.rx": -0.85, "armR.rz": -0.15, "head.rx": -0.45, "body.rx": -0.18, "body.z": 0.3, "halo.s": 0.4, "halo.spin": 5}),
                      (58, {"armR.rx": -0.85, "armR.rz": -0.15, "head.rx": -0.45, "body.rx": -0.18, "body.z": 0.32, "halo.s": 0.4, "halo.spin": 13}, "lin"),
                      (62, {"armR.rx": 0.7, "head.rx": 0.1, "body.rx": 0.12, "body.z": 0.3, "halo.s": 0.45, "halo.spin": 14.5}, "out"),
                      (70, {"armR.rx": -0.6, "armR.rz": -0.12, "head.rx": -0.4, "body.rx": -0.15, "body.z": 0.33, "halo.s": 0.4, "halo.spin": 17}),
                      (92, {"armR.rx": -0.7, "armR.rz": -0.12, "head.rx": -0.4, "body.rx": -0.18, "body.z": 0.35, "halo.s": 0.4, "halo.spin": 22, "tremor": 0.25}, "lin"),
                      (130, {"halo.spin": 26})],
                events=[(30, "silence_start"), (62, "punish"), (92, "silence_end")],
                meta=dict(name="Silent Requiem", rule="While the red halo burns (2 s), STOP: no moving, no attacking, no casting.",
                          fail="Anyone who acts: 50% max HP + silenced 5 s", duration_s=2))


def cantor_dirge(ctx, n=120):
    r = ctx["root"]
    starts = [(-2, -7), (0, -8), (2, -7)]
    ends = [(-9, -4), (0, -13), (9, -4)]
    for i in range(3):
        d = dummy(ctx, f"marked{i}", [(0, starts[i]), (38, starts[i]), (72, ends[i])])
        marker(ctx, f"note{i}", d, C["void"], 14 + 8 * i, 84, "note")
        place(disk(6, C["void"]).obj(f"{ctx['prefix']}-blast{i}", r), n, ends[i], lambda f: tele(f, 60, 84, 92, 0.05), z=0.04 + 0.01 * i)
        place(ring(5.5, 6.3, C["white"]).obj(f"{ctx['prefix']}-flash{i}", r), n, ends[i], lambda f: pop(f, 84, 10, 0.4), z=0.06)
    ks = [(0, {})]
    for i, t in enumerate((14, 22, 30)):
        ks += [(t - 4, {"armR.rx": -0.45, "body.rz": (i - 1) * 0.35, "head.rz": (i - 1) * 0.4}), (t, {"armR.rx": 0.75, "body.rx": 0.08, "body.rz": (i - 1) * 0.3, "head.rz": (i - 1) * 0.35}, "out")]
    ks += [(60, {"armR.rx": -0.9, "armR.rz": -0.15, "body.rx": -0.12, "head.rx": -0.3, "halo.s": 0.2}), (76, {"armR.rx": -0.95, "armR.rz": -0.15, "head.rx": -0.32, "tremor": 0.4}),
           (84, {"armR.rx": 1.1, "body.rx": 0.22, "head.rx": 0.2}, "out"), (96, {"armR.rx": 0.9, "body.rx": 0.18}), (120, {})]
    return dict(keys=ks, events=[(14, "mark"), (22, "mark"), (30, "mark"), (84, "explode")],
                meta=dict(name="Dirge Marks", rule="3 players get a note. Marked players run APART: each note explodes 6 m wide. Overlaps add up.",
                          fail="Each overlapping explosion +60% max HP (2 overlaps kill)", marks=3, radius_m=6))


def cantor_rites(ctx, n=150):
    r = ctx["root"]
    runes = [(9 * math.sin(a), -9 * math.cos(a)) for a in (0, TAU / 3, 2 * TAU / 3)]
    for i, p in enumerate(runes):
        place(disk(1.6, C["safe"], 24).obj(f"{ctx['prefix']}-rune{i}", r), n, p, lambda f: tele(f, 12, 112, 118, 0.04))
        place(ring(1.6, 2.0, C["good"]).obj(f"{ctx['prefix']}-rune-lit{i}", r), n, p, lambda f, i=i: 0.001 if f < 60 + 10 * i or f > 112 else 1.0, z=0.05)
        dummy(ctx, f"player{i}", [(0, (p[0] * 0.5 + 1.5, p[1] * 0.5)), (20, (p[0] * 0.5 + 1.5, p[1] * 0.5)), (60 + 10 * i, p)])
    sphere = M()
    for x in (-1, 0, 1):
        for y in (-1, 0, 1):
            for z in (-1, 0, 1):
                if abs(x) + abs(y) + abs(z) <= 2:
                    sphere.box((x * 0.55, y * 0.55, z * 0.55), (0.55, 0.55, 0.55), C["bone"] if (x + y + z) % 2 else C["void"])
    s = sphere.obj(f"{ctx['prefix']}-skull-sphere", r)
    anim(s, n, lambda f: ((0, 0.3, 8.2), (0, 0, f * 0.08), 0.001 if f < 16 or f > 116 else 0.3 + 1.2 * min(1, (f - 16) / 90)))
    place(disk(3, C["white"], 16).obj(f"{ctx['prefix']}-shatter", r), n, (0, 0.3), lambda f: pop(f, 112, 10, 2.0), z=8.2)
    ch = {"armR.rx": -0.8, "armR.rz": -0.18, "head.rx": -0.45, "body.rx": -0.18, "body.z": 0.6, "halo.s": 0.5}
    return dict(keys=[(0, {"halo.spin": 0}), (20, dict(ch, **{"halo.spin": 4})), (100, dict(ch, **{"halo.spin": 20, "tremor": 0.4}), "lin"),
                      (112, dict(ch, **{"halo.spin": 23, "tremor": 1.0})),
                      (122, {"body.rx": 0.35, "body.z": -0.2, "head.rx": 0.4, "armR.rx": 1.2, "halo.spin": 26}, "out"), (150, {"halo.spin": 28})],
                events=[(12, "runes"), (16, "channel"), (112, "interrupted")],
                meta=dict(name="Last Rites", rule="3 grave runes appear. Stand on ALL 3 at the same time to break the channel (5 s).",
                          fail="The channel finishes: 90% max HP to everyone", runes=3, channel_s=5))


def queen_acid(ctx, n=120):
    r = ctx["root"]
    route = [(0, (-6, -8)), (34, (-6, -8)), (50, (-10, -3)), (66, (-12, 2)), (82, (-11, 7))]
    d = dummy(ctx, "kiter", route)
    for i, t in enumerate((40, 56, 72)):
        spot = path_at(route, t - 6)
        place(disk(3, C["acid"], 20).obj(f"{ctx['prefix']}-puddle{i}", r), n, tuple(spot), lambda f, t=t: 0.001 if f < t else min(1, (f - t) / 5), z=0.03 + 0.005 * i)
        blob = M().box((0, 0, 0), (0.6, 0.6, 0.6), C["acid"], (0.5, 0.5, 0))
        o = blob.obj(f"{ctx['prefix']}-spit{i}", r)
        anim(o, n, lambda f, t=t, spot=spot: (tuple(Vector((0, -3.5, 3.5)).lerp(Vector((spot.x, spot.y, 0)), max(0, min(1, (f - t + 12) / 12))) + Vector((0, 0, 3 * math.sin(math.pi * max(0, min(1, (f - t + 12) / 12)))))),
                                              (f * 0.3, f * 0.2, 0), 1.0 if t - 12 <= f < t else 0.001))
    dummy(ctx, "camper", [(0, (6, -8)), (120, (6, -8))], hit=58, hit_kind="fall", fail=True)
    place(disk(3, C["acid"], 20).obj(f"{ctx['prefix']}-puddle-camper", r), n, (6, -8), lambda f: 0.001 if f < 44 else 1.0, z=0.035)
    rear = {"front.lift": 0.7, "body.rx": -0.35, "body.z": 0.4, "head.rx": -0.3}
    ks = [(0, {}), (22, rear)]
    for t in (40, 56, 72):
        ks += [(t - 12, dict(rear, **{"head.rx": -0.4})), (t - 8, dict(rear, **{"head.rx": 0.35, "body.y": -0.3}), "out")]
    ks += [(92, rear), (120, {})]
    return dict(keys=ks, events=[(28, "spit"), (44, "spit"), (60, "spit")],
                meta=dict(name="Acid Rain", rule="Acid lands where you stand, 3 times. Keep moving and drop the puddles at the arena edge. Puddles stay 20 s.",
                          fail="Standing in acid: 20% max HP per second", waves=3, puddle_radius_m=3, puddle_s=20))


def queen_bomb(ctx, n=120):
    r = ctx["root"]
    tgt = (5.0, -12.0)
    place(disk(4, C["safe"]).obj(f"{ctx['prefix']}-soak", r), n, tgt, lambda f: tele(f, 20, 80, 86, 0.04))
    for k in range(3):
        mk = M().box((0, 0, 0), (0.4, 0.4, 0.4), C["safe"], (0.6, 0.6, 0))
        place(mk.obj(f"{ctx['prefix']}-count{k}", r), n, (tgt[0] - 0.9 + 0.9 * k, tgt[1] + 4.6), lambda f: tele(f, 20, 80, 86, 0.1), z=0.6)
    egg = M().box((0, 0, 0), (1.2, 1.2, 1.5), C["bone"]).box((0, 0, 0.1), (0.9, 1.3, 0.6), C["acid"])
    e = egg.obj(f"{ctx['prefix']}-egg", r, glow=0)
    anim(e, n, lambda f: (tuple(Vector((0, -3.8, 4.0)).lerp(Vector((tgt[0], tgt[1], 0.7)), ease("io", max(0, min(1, (f - 30) / 50)))) + Vector((0, 0, 6 * math.sin(math.pi * max(0, min(1, (f - 30) / 50)))))),
                          (f * 0.1, 0, 0), 1.0 if 30 <= f < 80 else 0.001))
    place(ring(3.5, 4.5, C["acid"]).obj(f"{ctx['prefix']}-burst", r), n, tgt, lambda f: pop(f, 80, 12, 1.2))
    for i, (x, y) in enumerate(((-4, -7), (0, -6), (6, -6))):
        dummy(ctx, f"soaker{i}", [(0, (x, y)), (24, (x, y)), (66, (tgt[0] + 1.4 * math.cos(i * 2.1), tgt[1] + 1.4 * math.sin(i * 2.1)))])
    return dict(keys=[(0, {}), (18, {"front.lift": 0.6, "body.rx": -0.4, "body.z": 0.3, "head.rx": -0.45, "body.sz": 0.06}),
                      (30, {"front.lift": 0.2, "body.rx": 0.2, "body.y": -0.4, "head.rx": 0.4, "body.sz": -0.05}, "out"),
                      (50, {"front.lift": 0.1, "body.rx": 0.05}), (120, {})],
                events=[(20, "mark"), (30, "spit"), (80, "burst")],
                meta=dict(name="Brood Bomb", rule="An egg flies at the farthest player. At least 3 players must stand in the gold circle to split the burst.",
                          fail="Fewer than 3 inside: everyone inside takes 90% max HP and 4 scarabs hatch", soak_min=3, radius_m=4))


def queen_venom(ctx, n=120):
    r = ctx["root"]
    tank = dummy(ctx, "tank", [(0, (0, -6.5)), (74, (0, -6.5)), (96, (-5, -8))])
    swap = dummy(ctx, "second-tank", [(0, (5, -9)), (62, (5, -9)), (78, (0.5, -6.3))])
    for k in range(4):
        st = M().box((0, 0, 0), (0.28, 0.28, 0.28), C["acid"], (0.6, 0.6, 0))
        o = st.obj(f"{ctx['prefix']}-stack{k}", tank)
        t = 16 + 16 * k
        anim(o, n, lambda f, k=k, t=t: ((-0.45 + 0.3 * k, 0, 2.3), (0, 0, f * 0.2), 0.001 if f < t or f > 100 else 1.0))
    marker(ctx, "taunt", swap, C["blue"], 62, 100, "diamond", 1.3)
    ks = [(0, {})]
    for t in (16, 32, 48, 64):
        ks += [(t - 7, {"head.rx": -0.3, "body.y": 0.3, "front.lift": 0.3}), (t, {"head.rx": 0.35, "body.y": -0.5, "body.rx": 0.1}, "out")]
    ks += [(80, {"body.rz": 0.0}), (96, {"body.rz": -0.05, "head.rz": 0.1}), (120, {})]
    return dict(keys=ks, events=[(16, "bite"), (32, "bite"), (48, "bite"), (64, "bite"), (78, "taunt")],
                meta=dict(name="Venom Stacks", rule="Each bite adds Venom to the tank. At 4 stacks the second tank must taunt and take the Queen.",
                          fail="At 5 stacks the Venom bursts: 50% max HP to everyone within 8 m, and the tank dies", swap_at=4, burst_radius_m=8))


# ================================================================== VOID RIFT
def sovereign_collapse(ctx, n=130):
    r = ctx["root"]
    place(disk(10, C["danger"]).obj(f"{ctx['prefix']}-collapse", r), n, (0, 0), lambda f: tele(f, 16, 100))
    place(ring(10, 10.8, C["safe"]).obj(f"{ctx['prefix']}-edge", r), n, (0, 0), lambda f: tele(f, 16, 100, 110, 0))
    sp = M()
    for k in range(6):
        a = k * TAU / 6
        sp.fan([(0, 0), (2.8 * math.sin(a), -2.8 * math.cos(a)), (2.8 * math.sin(a + 0.35), -2.8 * math.cos(a + 0.35))], C["void"], 0.05)
    s = sp.obj(f"{ctx['prefix']}-vortex", r)
    anim(s, n, lambda f: ((0, 0, 0), (0, 0, -f * 0.25), 0.001 if f < 16 or f > 100 else 1 + 1.5 * (f - 16) / 84))
    place(disk(10.5, C["white"]).obj(f"{ctx['prefix']}-blast", r), n, (0, 0), lambda f: pop(f, 100, 8, 0.15), z=0.06)
    for i, a in enumerate((-1.2, 0.3, 1.6)):
        dummy(ctx, f"player{i}", [(0, (5 * math.sin(a), -5 * math.cos(a))), (20, (4.2 * math.sin(a), -4.2 * math.cos(a))),
                                  (90, (11.8 * math.sin(a), -11.8 * math.cos(a)))])
    dummy(ctx, "caught", [(0, (-2, 5)), (100, (-1.2, 3))], hit=100, fail=True)
    return dict(keys=[(0, {"orbit.spin": 0}), (16, {"armL.rz": -0.9, "armR.rz": 0.9, "armL.rx": -1.2, "armR.rx": -1.2, "head.rx": -0.3, "orbit.s": 0.3, "orbit.spin": 3, "body.z": 0.5}),
                      (96, {"armL.rz": -0.2, "armR.rz": 0.2, "armL.rx": -2.2, "armR.rx": -2.2, "head.rx": -0.4, "orbit.s": -0.4, "orbit.spin": 30, "body.z": 0.8, "tremor": 0.6}, "in"),
                      (104, {"armL.rz": -1.2, "armR.rz": 1.2, "armL.rx": -0.6, "armR.rx": -0.6, "head.rx": 0.2, "orbit.s": 0.6, "orbit.spin": 33, "body.z": 0.3}, "out"),
                      (130, {"orbit.spin": 36})],
                events=[(16, "pull_start"), (100, "collapse")],
                meta=dict(name="Void Collapse", rule="Everyone is pulled to the centre for 3 s. Run OUTWARD against the pull and reach the gold ring (10 m).",
                          fail="Inside the ring: 90% max HP + silenced 4 s", pull_s=3, radius_m=10))


def sovereign_polarity(ctx, n=120):
    r = ctx["root"]
    place(sector(15, -math.pi / 2, math.pi, C["safe"]).obj(f"{ctx['prefix']}-gold-half", r), n, (0, 0), lambda f: tele(f, 34, 90, 100, 0.02))
    place(sector(15, math.pi / 2, math.pi, C["void"]).obj(f"{ctx['prefix']}-void-half", r), n, (0, 0), lambda f: tele(f, 34, 90, 100, 0.02))
    place(disk(15, C["white"]).obj(f"{ctx['prefix']}-judgement", r), n, (0, 0), lambda f: pop(f, 90, 6, 0.02), z=0.06)
    plan = [("gold", C["safe"], (2, -6), (-7, -5)), ("void", C["void"], (-2, -7), (7, -6)), ("gold", C["safe"], (3, -9), (-8, 2)),
            ("void", C["void"], (-4, -9), (8, 3))]
    for i, (nm, col, a, b) in enumerate(plan):
        d = dummy(ctx, f"{nm}{i}", [(0, a), (40, a), (78, b)])
        marker(ctx, f"mark{i}", d, col, 22, 92, "diamond", 1.2)
    w = dummy(ctx, "wrong", [(0, (1, -11)), (40, (1, -11)), (78, (-6, -9))], hit=90, fail=True)
    marker(ctx, "mark-wrong", w, C["void"], 22, 92, "diamond", 1.2)
    return dict(keys=[(0, {}), (20, {"armL.rx": -2.4, "armR.rx": -2.4, "head.rx": -0.35, "body.z": 0.4, "orbit.s": 0.25, "orbit.spin": 2}),
                      (80, {"armL.rx": -2.5, "armR.rx": -2.5, "head.rx": -0.4, "body.z": 0.6, "orbit.s": 0.35, "orbit.spin": 14, "tremor": 0.4}),
                      (90, {"armL.rz": -1.0, "armR.rz": 1.0, "armL.rx": -0.8, "armR.rx": -0.8, "head.rx": 0.2, "orbit.spin": 17}, "out"), (120, {"orbit.spin": 19})],
                events=[(22, "mark"), (34, "halves"), (90, "judgement")],
                meta=dict(name="Polarity Decree", rule="Every player gets a gold or violet mark. Stand in the half of the arena with YOUR colour when it lands.",
                          fail="Wrong half: 80% max HP + stunned 3 s", marks=["gold", "violet"]))


def sovereign_lances(ctx, n=120):
    r = ctx["root"]
    tgts = [-0.6, 0.35, 1.2]
    for i, a in enumerate(tgts):
        hit = 40 + 20 * i
        o = lane(20, 2.2, C["danger"], start=1.0).obj(f"{ctx['prefix']}-lance-lane{i}", r)
        place(o, n, (0, 0), lambda f, hit=hit: tele(f, hit - 16, hit, hit + 4), rot=(0, 0, a))
        beam = lane(20, 0.8, C["white"], start=1.0).obj(f"{ctx['prefix']}-lance{i}", r)
        place(beam, n, (0, 0), lambda f, hit=hit: pop(f, hit, 6, 0.0), z=1.6, rot=(0, 0, a))
        p0 = (9 * math.sin(a), -9 * math.cos(a))
        side = (math.cos(a) * 3.2, math.sin(a) * 3.2)
        d = dummy(ctx, f"marked{i}", [(0, p0), (hit - 10, p0), (hit - 3, (p0[0] + side[0], p0[1] + side[1]))])
        marker(ctx, f"mark{i}", d, C["danger"], hit - 20, hit)
    dummy(ctx, "behind", [(0, (13 * math.sin(tgts[1]), -13 * math.cos(tgts[1]))), (120, (13 * math.sin(tgts[1]), -13 * math.cos(tgts[1])))], hit=60, fail=True)
    ks = [(0, {})]
    for i, a in enumerate(tgts):
        hit = 40 + 20 * i
        ks += [(hit - 10, {"armR.rx": -1.6, "armR.rz": 0.3, "body.rz": -a * 0.6, "head.rz": -a * 0.5, "orbit.spin": 2 * i}),
               (hit, {"armR.rx": -1.2, "body.rz": -a * 0.6, "body.rx": 0.15, "orbit.spin": 2 * i + 1.5}, "out")]
    ks += [(120, {"orbit.spin": 8})]
    return dict(keys=ks, events=[(24, "mark"), (40, "lance"), (60, "lance"), (80, "lance")],
                meta=dict(name="Rift Lances", rule="3 lances fire at the marked players, one after another. Step sideways out of each red lane. Never stand behind a marked player: lances pierce.",
                          fail="65% max HP per lance", lances=3, lane_width_m=2.2, length_m=20))


def weaver_tether(ctx, n=120):
    r = ctx["root"]
    pairs = [([(0, (-6, -6)), (30, (-6, -6)), (70, (-5, -8))], [(0, (-3, -9)), (30, (-3, -9)), (70, (-4, -9))], None),
             ([(0, (5, -6)), (30, (5, -6)), (70, (10, -3))], [(0, (3, -9)), (30, (3, -9)), (70, (1, -12))], 72)]
    for i, (pa, pb, snap) in enumerate(pairs):
        dummy(ctx, f"pair{i}a", pa, hit=snap, hit_kind="fall", fail=snap is not None)
        dummy(ctx, f"pair{i}b", pb, hit=snap, hit_kind="fall", fail=snap is not None)
        t = M().box((0, 0, 0), (1, 0.12, 0.12), C["void"]).box((0, 0, 0), (1, 0.05, 0.05), C["white"])
        o = t.obj(f"{ctx['prefix']}-tether{i}", r)

        def fn(f, pa=pa, pb=pb, snap=snap):
            a, b = path_at(pa, f), path_at(pb, f)
            d = b - a
            vis = 24 <= f < (snap if snap else 100)
            return ((a.x + b.x) / 2, (a.y + b.y) / 2, 1.2), (0, 0, math.atan2(d.y, d.x)), (max(0.001, d.length) if vis else 0.001, 1, 1)
        anim(o, n, fn)
        place(ring(4.8, 5.1, C["good"]).obj(f"{ctx['prefix']}-range{i}", r), n, tuple(path_at(pa, 40)), lambda f: tele(f, 24, 100, 106, 0), z=0.04)
    place(disk(1.5, C["white"], 12).obj(f"{ctx['prefix']}-snap", r), n, (7.5, -8), lambda f: pop(f, 72, 8, 2.0), z=1.2)
    return dict(keys=[(0, {"orbit.spin": 0}), (16, {"front.lift": 0.6, "body.rx": -0.3, "body.z": 0.3, "head.rx": -0.3, "orbit.s": 0.3, "orbit.spin": 3}),
                      (24, {"front.lift": 0.1, "body.rx": 0.15, "head.rx": 0.3, "orbit.spin": 5}, "out"), (100, {"orbit.spin": 18, "tremor": 0.2}, "lin"), (120, {"orbit.spin": 20})],
                events=[(24, "tether"), (72, "snap")],
                meta=dict(name="Null Tether", rule="Players are linked in pairs. Each pair must stay within 5 m of each other for 6 s.",
                          fail="The tether snaps: 70% max HP to both + silenced 4 s", max_distance_m=5, duration_s=6))


def weaver_cocoon(ctx, n=130):
    r = ctx["root"]
    vic = (-2.0, -9.0)
    dummy(ctx, "wrapped", [(0, vic), (130, vic)])
    co = M().box((0, 0, 1.0), (1.1, 1.1, 2.2), C["web"]).box((0, 0, 1.0), (1.2, 0.3, 2.0), "#c9bfff").box((0, 0, 1.0), (0.3, 1.2, 2.0), "#c9bfff")
    c = co.obj(f"{ctx['prefix']}-cocoon", r, glow=0)
    anim(c, n, lambda f: ((vic[0], vic[1], 0), (0, 0.06 * math.sin(f * 1.9) if 44 < f < 104 else 0, 0), (0.001 if f < 32 or f >= 104 else min(1, (f - 32) / 6))))
    strand = lane(9.2, 0.25, C["web"], start=0).obj(f"{ctx['prefix']}-web-shot", r)
    place(strand, n, (0, -1.2), lambda f: 1.0 if 20 <= f < 32 else 0.001, z=1.6, rot=(0, 0, math.atan2(vic[0], -(vic[1] + 1.2))))
    place(ring(1.4, 1.7, C["danger"]).obj(f"{ctx['prefix']}-timer", r), n, vic, lambda f: 0.001 if f < 32 or f >= 104 else 1 - 0.6 * (f - 32) / 72, z=0.04)
    place(disk(1.8, C["web"], 12).obj(f"{ctx['prefix']}-burst", r), n, vic, lambda f: pop(f, 104, 10, 1.0), z=1.0)
    for i, (x, y) in enumerate(((4, -6), (-7, -5), (1, -13))):
        dummy(ctx, f"helper{i}", [(0, (x, y)), (34, (x, y)), (52, (vic[0] + 1.6 * math.cos(i * 2.1), vic[1] + 1.6 * math.sin(i * 2.1)))])
    return dict(keys=[(0, {}), (14, {"head.rx": -0.35, "body.rx": -0.2, "front.lift": 0.4, "body.z": 0.2}),
                      (20, {"head.rx": 0.35, "body.rx": 0.15, "body.y": -0.3}, "out"), (40, {}), (130, {"orbit.spin": 6}, "lin")],
                events=[(20, "web_shot"), (32, "cocooned"), (104, "freed")],
                meta=dict(name="Cocoon", rule="A player is wrapped in a cocoon. Break it within 8 s (it has HP).",
                          fail="The player inside dies and the Nullweaver heals 5%", timer_s=8, heal_pct=5))


def weaver_floor(ctx, n=120):
    r = ctx["root"]
    tile = 4.0
    for ix in range(-3, 3):
        for iy in range(-4, 2):
            if (ix + iy) % 2 == 0:
                c = (ix * tile + tile / 2, iy * tile + tile / 2)
                o = M().fan([(-tile / 2, -tile / 2), (tile / 2, -tile / 2), (tile / 2, tile / 2), (-tile / 2, tile / 2)], C["void"]).obj(f"{ctx['prefix']}-web{ix}{iy}", r)
                place(o, n, c, lambda f: tele(f, 28, 84, 110, 0.03))
    place(disk(14, C["white"]).obj(f"{ctx['prefix']}-pulse", r), n, (0, 0), lambda f: pop(f, 84, 6, 0.0), z=0.06)
    safe = [(-6, -6), (2, -6), (-2, -10), (6, -10)]
    for i, p in enumerate(safe):
        dummy(ctx, f"player{i}", [(0, (p[0] + 1.5, p[1] + 1.8)), (34, (p[0] + 1.5, p[1] + 1.8)), (70, p)])
    dummy(ctx, "on-web", [(0, (-2, -6)), (120, (-2, -6))], hit=84, hit_kind="rooted", fail=True)
    return dict(keys=[(0, {}), (18, {"front.lift": 0.9, "body.rx": -0.45, "body.z": 0.4, "head.rx": -0.3}),
                      (28, {"front.lift": -0.2, "body.rx": 0.2, "body.z": -0.2, "head.rx": 0.25, "tremor": 0.5}, "out"),
                      (40, {}), (80, {"legs.lift": 0.25, "orbit.s": 0.2}), (86, {"legs.lift": -0.1, "body.z": -0.15, "tremor": 0.6}, "out"), (120, {})],
                events=[(28, "web_floor"), (84, "pulse")],
                meta=dict(name="Web Snare", rule="Half the floor turns into web tiles. When the web pulses, stand on a CLEAR tile.",
                          fail="On a web tile: rooted 4 s + 40% max HP", tile_m=4))


def behemoth_stampede(ctx, n=150):
    r = ctx["root"]
    place(lane(15, 4.5, C["danger"], start=2).obj(f"{ctx['prefix']}-lane1", r), n, (0, 0), lambda f: tele(f, 8, 34, 46))
    place(lane(15, 4.5, C["danger"], start=2).obj(f"{ctx['prefix']}-lane2", r), n, (0, -14), lambda f: tele(f, 56, 84, 96), rot=(0, 0, math.pi))
    d = dummy(ctx, "bait", [(0, (0, -12)), (20, (0, -16)), (40, (0, -16))])
    marker(ctx, "bait-mark", d, C["danger"], 6, 40)
    dummy(ctx, "player-side", [(0, (1.5, -8)), (22, (5.5, -8))])
    dummy(ctx, "player-other", [(0, (-1.8, -6)), (22, (-5.5, -6))])
    dummy(ctx, "in-lane", [(0, (0.4, -7)), (150, (0.4, -7))], hit=38, fail=True)
    run = {"gait": 1.0, "body.rx": 0.15, "head.rx": 0.25, "tail.rx": 0.3}
    return dict(keys=[(0, {}), (14, {"front.lift": 0.7, "body.rx": -0.35, "body.z": 0.3, "head.rx": -0.4}),
                      (22, {"body.rx": 0.2, "head.rx": 0.3, "body.y": 1.0}, "out"),
                      (30, dict(run, **{"body.y": -2})), (46, dict(run, **{"body.y": -14}), "lin"),
                      (52, {"body.y": -14.6, "body.rx": -0.1, "front.lift": 0.3}, "out"),
                      (68, {"body.y": -14.2, "body.rz": math.pi, "gait": 0.4}),
                      (74, dict(run, **{"body.y": -13.5, "body.rz": math.pi})), (92, dict(run, **{"body.y": 0.0, "body.rz": math.pi}), "lin"),
                      (100, {"body.y": 0.6, "body.rz": math.pi, "body.rx": -0.12, "front.lift": 0.3}, "out"),
                      (130, {"body.rz": TAU, "gait": 0.4}), (150, {"body.rz": TAU})],
                gait_cycles=6,
                events=[(8, "mark"), (30, "charge"), (74, "charge_back")],
                meta=dict(name="Umbral Stampede", rule="The Behemoth charges through the marked player and back. The marked player stands at the edge; everyone else stays out of the red lane.",
                          fail="Hit by the charge: 90% max HP + knocked away", charges=2, lane_width_m=4.5, length_m=15))


def behemoth_tail(ctx, n=100):
    r = ctx["root"]
    place(sector(9, math.pi, math.radians(240), C["danger"]).obj(f"{ctx['prefix']}-sweep", r), n, (0, 0), lambda f: tele(f, 10, 50))
    place(sector(9.2, 0, math.radians(120), C["safe"], r0=8.7).obj(f"{ctx['prefix']}-safe-front", r), n, (0, 0), lambda f: tele(f, 10, 50, 58, 0))
    for i, a in enumerate((-0.3, 0.3)):
        dummy(ctx, f"front{i}", [(0, (7 * math.sin(a), -7 * math.cos(a))), (50, (7 * math.sin(a), -7 * math.cos(a)))])
    dummy(ctx, "sidestep", [(0, (6.5, 2)), (14, (6.5, 2)), (42, (5.5, -5.5))])
    dummy(ctx, "behind", [(0, (-2, 7)), (50, (-2, 7))], hit=50, fail=True)
    return dict(keys=[(0, {}), (16, {"body.rz": 0.35, "tail.rz": -1.4, "tail.rx": 0.4, "head.rz": -0.4, "body.z": -0.2}),
                      (40, {"body.rz": 0.45, "tail.rz": -1.6, "tail.rx": 0.5, "head.rz": -0.5, "body.z": -0.25, "tremor": 0.5}),
                      (50, {"body.rz": -0.55, "tail.rz": 1.6, "tail.rx": 0.2, "head.rz": 0.4}, "out"),
                      (62, {"body.rz": -0.4, "tail.rz": 1.0}), (100, {})],
                events=[(10, "telegraph"), (50, "sweep")],
                meta=dict(name="Tail Sweep", rule="Only the FRONT is safe. The tail sweeps 240 degrees around the back and sides.",
                          fail="75% max HP + knocked back", safe_arc_deg=120, radius_m=9))


def behemoth_devour(ctx, n=130):
    r = ctx["root"]
    t1 = dummy(ctx, "tank", [(0, (0, -5.5)), (40, (0, -5.5)), (70, (-6, -7))])
    t2 = dummy(ctx, "second-tank", [(0, (6, -8)), (56, (6, -8)), (80, (0.3, -5.6))])
    dg = M().box((0, 0, 0), (0.5, 0.5, 0.5), C["acid"], (0.6, 0.6, 0))
    o = dg.obj(f"{ctx['prefix']}-digesting", t1)
    anim(o, n, lambda f: ((0, 0, 2.4), (0, 0, f * 0.2), 0.001 if f < 36 else 1 + 0.15 * math.sin(f * 0.5)))
    marker(ctx, "taunt", t2, C["blue"], 56, 104, "diamond", 1.3)
    for i, t in enumerate((36, 104)):
        place(sector(5, 0, math.radians(70), C["danger"]).obj(f"{ctx['prefix']}-bite{i}", r), n, (0, -1.5), lambda f, t=t: tele(f, t - 14, t))
    bite = lambda: {"head.rx": 0.5, "body.y": -1.2, "body.rx": 0.2, "front.lift": -0.1}
    wind = lambda: {"head.rx": -0.5, "body.y": 0.5, "body.rx": -0.2, "front.lift": 0.4}
    return dict(keys=[(0, {}), (26, wind()), (36, bite(), "out"), (54, {}), (94, wind()), (104, bite(), "out"), (130, {})],
                events=[(36, "devour"), (80, "taunt"), (104, "devour")],
                meta=dict(name="Devour", rule="Devour digests the tank for 6 s. The second tank must take the Behemoth before the next bite.",
                          fail="A second Devour on the digesting player kills them", digest_s=6))


def oracle_eclipse(ctx, n=130):
    r = ctx["root"]
    place(disk(17, C["night"], 48).obj(f"{ctx['prefix']}-darkness", r), n, (0, 0), lambda f: tele(f, 20, 100, 108, 0), z=0.02)
    lights = [(-7, -6), (0, -10), (7, -6)]
    for i, p in enumerate(lights):
        place(disk(2.8, C["safe"], 24).obj(f"{ctx['prefix']}-light{i}", r), n, p, lambda f: 0.001 if f < 26 or f > 104 else 1 - 0.3 * (f - 26) / 74, z=0.04)
        dummy(ctx, f"player{i}", [(0, (p[0] * 0.6, p[1] * 0.6 + 2)), (30, (p[0] * 0.6, p[1] * 0.6 + 2)), (80, p)])
    dummy(ctx, "in-dark", [(0, (10, 3)), (130, (10, 3))], hit=100, hit_kind="fall", fail=True)
    beam = M().box((0, -8, 0), (1.2, 16, 1.2), C["white"])
    place(beam.obj(f"{ctx['prefix']}-eye-flash", r), n, (0, 0), lambda f: pop(f, 100, 6, 0.0), z=3.2)
    return dict(keys=[(0, {"orbit.spin": 0}), (20, {"head.s": -0.35, "body.z": 0.4, "orbit.s": 0.3, "orbit.spin": 2}),
                      (96, {"head.s": -0.45, "body.z": 0.6, "orbit.s": 0.4, "orbit.spin": 16, "tremor": 0.3}, "lin"),
                      (100, {"head.s": 0.3, "body.z": 0.5, "orbit.s": 0.5, "orbit.spin": 17, "head.rx": 0.2}, "out"), (130, {"orbit.spin": 20})],
                events=[(20, "eye_closes"), (100, "eye_opens")],
                meta=dict(name="Total Eclipse", rule="The eye closes and the arena goes dark. Stand inside a light circle before the eye opens (circles shrink).",
                          fail="Outside the light: 80% max HP + blinded 4 s", lights=3, radius_m=2.8))


def oracle_prophecy(ctx, n=150):
    r = ctx["root"]
    quads = [0, math.pi / 2, math.pi, 3 * math.pi / 2]
    hits = [60, 80, 100, 120]
    for i, (a, h) in enumerate(zip(quads, hits)):
        place(sector(15, a + math.pi / 4, math.pi / 2, C["danger"], r0=2).obj(f"{ctx['prefix']}-quad{i}", r), n, (0, 0), lambda f, h=h, i=i: tele(f, 18 + 6 * i, h, h + 6, 0.02))
        num = M()
        for k in range(i + 1):
            num.box((0.55 * k - 0.275 * i, 0, 0), (0.35, 0.35, 0.8), C["safe"])
        cx, cy = 9 * math.sin(a + math.pi / 4), -9 * math.cos(a + math.pi / 4)
        place(num.obj(f"{ctx['prefix']}-number{i}", r), n, (cx, cy), lambda f, h=h, i=i: tele(f, 18 + 6 * i, h, h + 4, 0.05), z=0.5)
        place(disk(1.5, C["white"], 12).obj(f"{ctx['prefix']}-blast{i}", r), n, (cx, cy), lambda f, h=h: pop(f, h, 8, 3.0), z=0.08)
    q = lambda k: (9 * math.sin(quads[k] + math.pi / 4), -9 * math.cos(quads[k] + math.pi / 4))
    dummy(ctx, "follower", [(0, q(3)), (64, q(3)), (72, q(0)), (84, q(0)), (92, q(1)), (104, q(1)), (112, q(2))])
    dummy(ctx, "follower2", [(0, tuple(Vector(q(3)) * 0.7)), (66, tuple(Vector(q(3)) * 0.7)), (74, tuple(Vector(q(0)) * 0.7)), (86, tuple(Vector(q(0)) * 0.7)),
                              (94, tuple(Vector(q(1)) * 0.7)), (106, tuple(Vector(q(1)) * 0.7)), (114, tuple(Vector(q(2)) * 0.7))])
    dummy(ctx, "lost", [(0, q(2)), (100, q(2))], hit=100, fail=True)
    ks = [(0, {"orbit.spin": 0}), (18, {"head.rx": -0.2, "orbit.s": 0.25, "orbit.spin": 2})]
    for i, h in enumerate(hits):
        ks += [(h - 6, {"head.rz": quads[i] * 0.25 - 0.4, "orbit.spin": 2 + 3 * i, "orbit.s": 0.25}), (h, {"head.s": 0.2, "head.rz": quads[i] * 0.25 - 0.4, "orbit.spin": 3.5 + 3 * i}, "out")]
    ks += [(150, {"orbit.spin": 18})]
    return dict(keys=ks, events=[(18, "prophecy")] + [(h, f"blast_{i + 1}") for i, h in enumerate(hits)],
                meta=dict(name="Prophecy", rule="4 quadrants are numbered 1-4 and blast in that order. Wait in 4, then step into each quadrant right after it blasts.",
                          fail="70% max HP per blast", quadrants=4, interval_s=0.67))


def oracle_gaze(ctx, n=140):
    r = ctx["root"]
    for i in range(4):
        b = lane(16, 1.8, C["danger"], start=1.5).obj(f"{ctx['prefix']}-beam{i}", r)
        anim(b, n, lambda f, i=i: ((0, 0, 0.05), (0, 0, i * math.pi / 2 + (0 if f < 40 else min(math.pi / 2, (f - 40) / 70 * math.pi / 2))),
                                    0.001 if f < 24 or f > 112 else (0.5 if f < 40 else 1.0)))
        c = lane(16, 0.6, C["white"], start=1.5).obj(f"{ctx['prefix']}-beam-core{i}", r)
        anim(c, n, lambda f, i=i: ((0, 0, 1.4), (0, 0, i * math.pi / 2 + (0 if f < 40 else min(math.pi / 2, (f - 40) / 70 * math.pi / 2))),
                                    0.001 if f < 40 or f > 112 else 1.0))
    for i, rad in enumerate((6.0, 9.0)):
        pth = [(0, (rad * math.sin(math.pi / 4), -rad * math.cos(math.pi / 4)))]
        for f in range(40, 112, 8):
            a = math.pi / 4 + (f - 40) / 70 * math.pi / 2
            pth.append((f, (rad * math.sin(a), -rad * math.cos(a))))
        dummy(ctx, f"walker{i}", pth)
    dummy(ctx, "still", [(0, (7 * math.sin(math.pi / 4 + 0.3), -7 * math.cos(math.pi / 4 + 0.3))), (140, (7 * math.sin(math.pi / 4 + 0.3), -7 * math.cos(math.pi / 4 + 0.3)))], hit=64, fail=True)
    return dict(keys=[(0, {"orbit.spin": 0}), (24, {"head.s": 0.25, "body.z": 0.5, "orbit.s": 0.35, "orbit.spin": 1.5, "head.rx": 0.15}),
                      (110, {"head.s": 0.25, "body.z": 0.5, "orbit.s": 0.35, "orbit.spin": 1.5 + math.pi / 2, "body.rz": -math.pi / 2, "tremor": 0.2}, "lin"),
                      (140, {"orbit.spin": 3, "body.rz": -math.pi / 2})],
                events=[(24, "beams"), (40, "sweep_start"), (110, "sweep_end")],
                meta=dict(name="Sweeping Gaze", rule="4 beams turn clockwise a quarter circle. Walk WITH the gap between two beams.",
                          fail="Touching a beam: 50% max HP per tick", beams=4, sweep_deg=90, sweep_s=2.3))


SKILLS = {
    "ossuary-tyrant": [("verdict", tyrant_verdict), ("bone-cage", tyrant_cage), ("grave-toll", tyrant_toll)],
    "marrow-colossus": [("earthsplitter", colossus_split), ("marrow-quake", colossus_quake), ("crushing-grip", colossus_grip)],
    "grave-cantor": [("silent-requiem", cantor_requiem), ("dirge-marks", cantor_dirge), ("last-rites", cantor_rites)],
    "carrion-queen": [("acid-rain", queen_acid), ("brood-bomb", queen_bomb), ("venom-stacks", queen_venom)],
    "rift-sovereign": [("void-collapse", sovereign_collapse), ("polarity-decree", sovereign_polarity), ("rift-lances", sovereign_lances)],
    "nullweaver": [("null-tether", weaver_tether), ("cocoon", weaver_cocoon), ("web-snare", weaver_floor)],
    "umbral-behemoth": [("stampede", behemoth_stampede), ("tail-sweep", behemoth_tail), ("devour", behemoth_devour)],
    "eclipse-oracle": [("total-eclipse", oracle_eclipse), ("prophecy", oracle_prophecy), ("sweeping-gaze", oracle_gaze)],
}


def build_all(rigs, scene):
    global FXC
    FXC = bpy.data.collections.get("Skill FX") or bpy.data.collections.new("Skill FX")
    if FXC.name not in scene.collection.children:
        scene.collection.children.link(FXC)
    catalog = {}
    for boss, skills in SKILLS.items():
        R = rigs[boss]
        catalog[boss] = []
        for slug, fn in skills:
            catalog[boss].append(dict(run_skill(R, scene, slug, fn), slug=slug))
        print("skills", boss, [s for s, _ in skills])
    scene["skill_catalog"] = json.dumps(catalog)
    scene["ranged_auto"] = json.dumps({k: cantor_bolt(rigs[k], scene) for k in ("grave-cantor", "void-cantor")})
    return catalog


# ================================================================== Grave + Void Cantor: ranged auto attack (viewer fx + data)
CANTOR_BOLT = {"void-cantor": ("Void Bolt", C["void"], C["void2"], C["white"]),
               "grave-cantor": ("Grave Fire", "#ff9a3d", "#c2451a", "#fff1c2")}


def cantor_bolt(R, scene, n=30, launch=15, impact=24, rng=12.0):
    """auto clip = ranged cast: the scepter charges a bolt and launches it on frame 15 (the game's hit frame)."""
    global FXC
    FXC = bpy.data.collections.get("Skill FX") or bpy.data.collections.new("Skill FX")
    key = R.key
    name, c1, c2, hot = CANTOR_BOLT[key]
    arm = R.parts["right-arm"]
    zmax = max(v.co.z for v in arm.data.vertices)
    top = [v.co for v in arm.data.vertices if v.co.z > zmax - 0.25]
    tip_local = sum(top, Vector()) / len(top)                       # the glowing head of the scepter
    for o in R.parts.values():                                      # evaluate the baked auto clip
        o.animation_data.action = o.animation_data.nla_tracks[f"{key}-auto"].strips[0].action
    Rinv = R.root.matrix_world.inverted()
    tips = []
    for f in range(n + 1):
        scene.frame_set(f)
        bpy.context.view_layer.update()
        tips.append(Rinv @ arm.matrix_world @ tip_local)
    for o in R.parts.values():
        o.animation_data.action = None
    fxroot = bpy.data.objects.new(f"fx-{key}-auto", None)
    FXC.objects.link(fxroot)
    fxroot.location = R.root.location
    ctx = {"root": fxroot, "prefix": f"fx-{key}-auto", "n": n}
    target = Vector((0.0, -rng, 1.1))
    charge = M().box((0, 0, 0), (0.28, 0.28, 0.28), c1, (0.6, 0.6, 0)).box((0, 0, 0), (0.14, 0.14, 0.14), hot)
    anim(charge.obj(f"fx-{key}-auto-charge", fxroot), n,
         lambda f: (tuple(tips[f]), (f * 0.4, f * 0.3, 0), 0.001 if f < 4 or f > launch else 0.4 + 1.2 * (f - 4) / (launch - 4)))
    bolt = M().box((0, 0, 0), (0.42, 0.42, 0.42), c1, (0.6, 0.6, 0)).box((0, 0, 0), (0.22, 0.22, 0.22), hot, (0, 0.6, 0.6))
    start = tips[launch]
    pos = lambda f: start.lerp(target, max(0.0, min(1.0, (f - launch) / (impact - launch))))
    anim(bolt.obj(f"fx-{key}-auto-bolt", fxroot), n, lambda f: (tuple(pos(f)), (f * 0.5, 0, f * 0.3), 1.0 if launch <= f < impact else 0.001))
    for k in range(4):
        tr = M().box((0, 0, 0), (0.2, 0.2, 0.2), c2 if k % 2 else c1, (0.6, 0.6, 0))
        anim(tr.obj(f"fx-{key}-auto-trail{k}", fxroot), n,
             lambda f, k=k: (tuple(pos(f - 1 - k)), (0, 0, f * 0.4), (0.8 - 0.15 * k) if launch + 1 + k <= f < impact + k else 0.001))
    burst = M().box((0, 0, 0), (0.9, 0.9, 0.9), c1, (0.6, 0.6, 0)).box((0, 0, 0), (0.5, 0.5, 0.5), hot)
    anim(burst.obj(f"fx-{key}-auto-impact", fxroot), n, lambda f: (tuple(target), (0, 0, f * 0.3), pop(f, impact, 6, 1.0)))
    flash = M().box((0, 0, 0), (0.5, 0.5, 0.5), hot, (0.6, 0.6, 0))
    anim(flash.obj(f"fx-{key}-auto-muzzle", fxroot), n, lambda f: (tuple(start), (0, 0, f), pop(f, launch, 4, 0.8)))
    dummy(ctx, "target", [(0, (0, -rng)), (n, (0, -rng))], hit=impact, hit_kind="rooted")
    meta = dict(name=f"{name} (auto attack)", rule=f"Ranged auto attack: charges the scepter and fires a bolt at its target ({rng:.0f} m). Launch on frame 15 (the game's hit frame), lands 0.3 s later.",
                fail="Normal auto-attack damage; the bolt flies straight, so it can be dodged sideways", range_m=rng, projectile_speed_mps=round(rng / ((impact - launch) / 30), 1),
                style="projectile", clip=f"{key}-auto", frames=n + 1, seconds=round(n / 30, 2))
    fxroot["skill"] = json.dumps(meta)
    fxroot["events"] = json.dumps([{"frame": 4, "time": 0.133, "name": "charge"}, {"frame": launch, "time": round(launch / 30, 3), "name": "launch"},
                                   {"frame": impact, "time": round(impact / 30, 3), "name": "hit"}])
    fxroot["boss"] = key
    fxroot["frames"] = n
    fxroot["clip"] = "auto"
    return meta
