"""Instant Combat monsters: motion engine (shared by ic_kit.py).

The models are rigid voxel parts under 'body' (head, arms, legs, tail, halo, orbit). Every clip is baked on every
frame from key poses with easing, per-part overlap (head, arms, tail follow later), a life layer (breathing,
weight shift, looking around) and real gaits (biped, 4-leg trot, 6/8-leg alternating tripods).

Controls used in key poses (all optional, 0 = rest):
  body.x/.y/.z (m)  body.rx/.ry/.rz (rad; +rx leans forward, forward = -Y)  body.sx/.sz (squash)
  head.rx/.ry/.rz/.z   armL.rx/.ry/.rz  armR.rx/.ry/.rz (-rx raises the arm forward/up)
  legL.rx/.z legR.rx/.z (bipeds)  stance (legs apart)  front.lift/back.lift (insects, beasts: raise legs)
  tail.rx/.rz   orbit.spin/.s   halo.spin/.s   tremor (shake amplitude)   gait (walk amplitude 0..1)
"""
import math

import bpy
import numpy as np
from mathutils import Euler, Vector

TAU = 2 * math.pi
FPS = 30

KIND = {
    "bone-reaver": "biped", "ossuary-tyrant": "biped", "marrow-colossus": "biped",
    "grave-cantor": "caster", "void-cantor": "caster", "rift-sovereign": "caster", "eclipse-oracle": "caster",
    "ossuary-scarab": "insect", "carrion-queen": "insect", "nullweaver": "insect",
    "rift-stalker": "beast", "umbral-behemoth": "beast",
    "bone-anchor": "object", "rift-anchor": "object", "brood-nest": "object",
}
HEIGHT = {"bone-reaver": 2.3, "ossuary-scarab": 1.55, "rift-stalker": 1.85, "void-cantor": 2.45, "ossuary-tyrant": 4.8,
          "marrow-colossus": 4.8, "grave-cantor": 4.8, "carrion-queen": 4.4, "rift-sovereign": 4.9, "nullweaver": 4.4,
          "umbral-behemoth": 4.7, "eclipse-oracle": 4.9, "bone-anchor": 2.2, "rift-anchor": 2.2, "brood-nest": 1.5}
HOVER = {"void-cantor": 0.18, "rift-sovereign": 0.35, "eclipse-oracle": 0.22}
SPIN_AXIS = {"rift-sovereign": 2, "nullweaver": 1, "eclipse-oracle": 1, "grave-cantor": 1, "void-cantor": 1}
# parts that are really a big chunk of the torso: they only sway a little
ARM_DAMP = {"grave-cantor": {"armL": 0.12}, "void-cantor": {"armL": 0.12}}
# scepter casters: the staff arm is a straight scepter held upright, -rx tilts it back (wind-up), +rx swings it forward
SCEPTER = {"grave-cantor", "void-cantor"}
# rings whose pivot is far from the mesh (spinning would fling them around): keep them fixed on the body
STATIC_PARTS = {("void-cantor", "halo")}
BOSSES = ["ossuary-tyrant", "marrow-colossus", "grave-cantor", "carrion-queen",
          "rift-sovereign", "nullweaver", "umbral-behemoth", "eclipse-oracle"]
LAG = {"head": 2.0, "arm": 1.0, "tail": 4.0, "halo": 3.0, "orbit": 1.5}


def ease(kind, u):
    u = max(0.0, min(1.0, u))
    if kind == "lin":
        return u
    if kind == "out":                      # fast start, soft landing (strikes)
        return 1 - (1 - u) ** 3
    if kind == "in":
        return u ** 3
    if kind == "back":                     # overshoot then settle
        s = 1.7
        u -= 1
        return u * u * ((s + 1) * u + s) + 1
    return u * u * (3 - 2 * u)


class Track:
    """key poses: [(frame, {control: value}, ease)]; missing controls are 0 (rest)."""

    def __init__(self, keys):
        self.keys = sorted([(k[0], k[1], k[2] if len(k) > 2 else "io") for k in keys], key=lambda k: k[0])

    def __call__(self, name, f):
        ks = self.keys
        if f <= ks[0][0]:
            return ks[0][1].get(name, 0.0)
        for (f0, a, _), (f1, b, e) in zip(ks, ks[1:]):
            if f <= f1:
                u = ease(e, (f - f0) / (f1 - f0) if f1 > f0 else 1.0)
                va, vb = a.get(name, 0.0), b.get(name, 0.0)
                return va + (vb - va) * u
        return ks[-1][1].get(name, 0.0)


class Rig:
    def __init__(self, root):
        self.root = root
        self.key = root.name
        self.kind = KIND[self.key]
        self.h = HEIGHT[self.key]
        self.parts = {o.name[len(self.key) + 1:]: o for o in root.children_recursive if o.type == 'MESH'}
        self.base = {k: o.location.copy() for k, o in self.parts.items()}
        self.coords = {o: np.array([tuple(v.co) for v in o.data.vertices]) for o in self.parts.values()}
        self.legs = sorted([k for k in self.parts if k.startswith("leg-")])

    # ---------------------------------------------------------------- one frame
    def pose(self, K, f, n, loop, life=1.0, gait_cycles=0, gait_amp=None):
        """returns {part: (loc, rot, scale)} at frame f of an n-frame clip"""
        h, key = self.h, self.key
        heavy = min(1.0, h / 4.8)
        slow = 1.0 if h < 3 else 0.75
        t = f / n
        # life layer: integer cycles over the clip so loops close
        bc = max(1, round(n / (FPS * 1.6 / slow))) if loop else n / (FPS * 1.6 / slow)
        br = math.sin(TAU * bc * t)
        br2 = math.sin(TAU * bc * t * (1 if loop else 1) + 1.3)
        look = math.sin(TAU * (max(1, bc // 2) if loop else bc / 2) * t + 0.4)
        tr = K("tremor", f)
        shake = tr * math.sin(f * 2.9) * 0.6 + tr * math.sin(f * 4.7 + 1) * 0.4

        def k(name, lag=0.0):
            return K(name, f - lag * (1 + 0.5 * heavy))

        out = {}
        hover = HOVER.get(key, 0.0)
        g_amp = k("gait") if gait_amp is None else gait_amp
        gphase = gait_cycles * t
        bob = 0.0
        if g_amp and self.kind in ("biped", "beast", "insect"):
            bob = abs(math.sin(TAU * gphase)) * h * 0.022 * g_amp
        if self.kind == "caster" and g_amp:
            bob = math.sin(TAU * 2 * gphase) * h * 0.012 * g_amp
        # body
        bz = k("body.z") + hover * (1 + 0.25 * math.sin(TAU * bc * t)) + life * br * h * (0.006 + 0.004 * (self.kind == "caster")) + bob
        rx = k("body.rx") + life * 0.018 * br2 + (0.06 * g_amp if self.kind in ("beast", "biped") else 0.0) + 0.012 * shake
        ry = k("body.ry") + life * 0.022 * math.sin(TAU * bc * t * 0.5 + 0.8) * (1 if not loop else 0) \
            + (0.05 * g_amp * math.sin(TAU * gphase) if self.kind == "biped" else 0.0) + 0.015 * shake
        rz = k("body.rz") + life * 0.03 * look * (self.kind != "object") + (0.035 * g_amp * math.sin(TAU * gphase) if self.kind in ("biped", "caster") else 0)
        sx = 1 + k("body.sx") + (life * 0.012 * br if self.kind == "object" else 0)
        sz = 1 + k("body.sz") + (life * 0.02 * br if self.kind == "object" else life * 0.006 * br)
        out["body"] = (Vector((k("body.x") + 0.02 * shake * h / 4, k("body.y"), bz)), (rx, ry, rz), (sx, sx, sz))
        # head: follows later, looks around
        if "head" in self.parts:
            hr = (k("head.rx", LAG["head"]) + life * 0.03 * br2 - 0.04 * g_amp,
                  k("head.ry", LAG["head"]) + 0.01 * shake,
                  k("head.rz", LAG["head"]) + life * 0.16 * look * (0.4 if self.kind == "object" else 1))
            hz = k("head.z", LAG["head"]) + (life * 0.03 * br if self.kind == "object" else 0)
            hs = 1 + k("head.s", LAG["head"]) + (life * 0.04 * br2 if self.kind == "object" else 0)
            out["head"] = (Vector((0, 0, hz)), hr, (hs, hs, hs))
        # arms
        for side, name in ((-1, "left-arm"), (1, "right-arm")):
            if name not in self.parts:
                continue
            c = "armL" if side < 0 else "armR"
            if key == "ossuary-tyrant":            # one part: both arms + tablet
                c = "armR"
            swing = 0.0
            if g_amp and self.kind == "biped":
                swing = 0.35 * g_amp * math.sin(TAU * gphase + (0 if side < 0 else math.pi)) * (0.5 if key == "ossuary-tyrant" else 1)
            if g_amp and self.kind == "caster":
                swing = 0.12 * g_amp * math.sin(TAU * gphase + (0 if side < 0 else math.pi))
            damp = ARM_DAMP.get(key, {}).get(c, 1.0)
            arx = k(c + ".rx", LAG["arm"]) * damp
            if key == "ossuary-tyrant":            # the tablet block is held up: wind-ups lean it back a little, hits swing it forward
                arx = arx * 0.3 if arx < 0 else arx * 2.0
            out[name] = (Vector((0, 0, 0)),
                         (arx + swing + life * 0.03 * br * side + 0.02 * shake,
                          k(c + ".ry", LAG["arm"]) * damp + side * life * 0.025 * (1 - br) * 0.5,
                          k(c + ".rz", LAG["arm"]) * damp), (1, 1, 1))
        # legs
        for name in self.legs + [n for n in ("left-leg", "right-leg") if n in self.parts]:
            b = self.base[name]
            side = -1 if b.x < 0 else 1
            if self.kind == "biped":
                c = "legL" if side < 0 else "legR"
                ph = gphase + (0 if side < 0 else 0.5)
                sw = -0.42 * g_amp * math.sin(TAU * ph)
                lift = max(0.0, math.cos(TAU * ph)) * h * 0.035 * g_amp
                st = k("stance")
                out[name] = (Vector((0, 0, lift + k(c + ".z"))), (k(c + ".rx") + sw, st if side < 0 else -st, 0), (1, 1, 1))
            elif self.kind == "beast":
                front = b.y < 0
                grp = (front and side < 0) or (not front and side > 0)
                ph = gphase + (0 if grp else 0.5)
                sw = -0.5 * g_amp * math.sin(TAU * ph)
                lift = max(0.0, math.cos(TAU * ph)) * h * 0.05 * g_amp
                raise_ = k("front.lift") if front else k("back.lift")
                out[name] = (Vector((0, 0, lift)), (sw - raise_, 0, 0), (1, 1, 1))
            elif self.kind == "insect":
                idx = int(name.split("-")[1])
                nl = len(self.legs)
                row = idx % (nl // 2)
                grp = (row + (0 if side < 0 else 1)) % 2
                ph = gphase + 0.5 * grp
                lift = max(0.0, math.cos(TAU * ph)) * 0.32 * g_amp
                swing = 0.3 * g_amp * math.sin(TAU * ph)
                front = row == 0
                back = row == nl // 2 - 1
                raise_ = (k("front.lift") if front else 0) + (k("back.lift") if back else 0) + k("legs.lift")
                twitch = life * 0.04 * math.sin(TAU * bc * t + idx * 1.7)
                spl = k("legs.splay")
                out[name] = (Vector((0, 0, 0)), (0, -side * (lift + raise_ + twitch - spl), -side * swing), (1, 1, 1))
        if "tail" in self.parts:
            wag = life * 0.25 * math.sin(TAU * bc * t + 0.6) + 0.3 * g_amp * math.sin(TAU * gphase + 1.2)
            out["tail"] = (Vector((0, 0, 0)), (k("tail.rx", LAG["tail"]), 0, k("tail.rz", LAG["tail"]) + wag), (1, 1, 1))
        for ring in ("orbit", "halo"):
            if ring in self.parts and (key, ring) in STATIC_PARTS:
                out[ring] = (Vector((0, 0, 0)), (0, 0, 0), (1, 1, 1))
            elif ring in self.parts:
                ax = SPIN_AXIS.get(key, 2)
                spin = k(ring + ".spin", LAG[ring])
                r = [0.0, 0.0, 0.0]
                r[ax] = spin
                s = 1 + k(ring + ".s", LAG[ring]) + life * 0.03 * br
                out[ring] = (Vector((0, 0, life * 0.04 * br2)), tuple(r), (s, s, s))
        return out

    # ---------------------------------------------------------------- apply / measure / bake
    def apply(self, pose):
        for name, o in self.parts.items():
            loc, rot, scl = pose.get(name, (Vector(), (0, 0, 0), (1, 1, 1)))
            o.location = self.base[name] + loc
            o.rotation_euler = Euler(rot)
            o.scale = scl

    def lowest(self):
        bpy.context.view_layer.update()
        low = 1e9
        R = self.root.matrix_world.inverted()
        for o, vs in self.coords.items():
            M = np.array(R @ o.matrix_world)
            z = vs @ M[2, :3] + M[2, 3]
            low = min(low, float(z.min()))
        return low

    def bake(self, clip, n, fn, loop, death=False, keep_air=False):
        """fn(f) -> pose dict; ground-corrects the body and writes one action per part (+ NLA track 'clip')."""
        frames = []
        for f in range(n + 1):
            p = fn(f if not loop or f < n else 0)
            self.apply(p)
            low = self.lowest()
            if death and f >= n * 0.7:
                lift = -low
            elif keep_air:
                lift = max(0.0, -low)
            else:
                lift = max(0.0, -low)
            loc, rot, scl = p["body"]
            p["body"] = (loc + Vector((0, 0, lift)), rot, scl)
            frames.append(p)
        if loop:
            frames[n] = frames[0]
        acts = {}
        for name, o in self.parts.items():
            act = bpy.data.actions.new(f"{clip}-{name}")
            o.animation_data_create()
            o.animation_data.action = act
            o.rotation_mode = 'XYZ'
            chans = []
            for path, n_ in (("location", 3), ("rotation_euler", 3), ("scale", 3)):
                for i in range(n_):
                    fc = act.fcurve_ensure_for_datablock(o, path, index=i)
                    chans.append((fc, path, i))
            for fc, path, i in chans:
                co = []
                for f, p in enumerate(frames):
                    loc, rot, scl = p.get(name, (Vector(), (0, 0, 0), (1, 1, 1)))
                    v = (self.base[name] + loc)[i] if path == "location" else (rot[i] if path == "rotation_euler" else scl[i])
                    co += [f, v]
                fc.keyframe_points.add(len(frames))
                fc.keyframe_points.foreach_set("co", co)
                for kp in fc.keyframe_points:
                    kp.interpolation = 'LINEAR'
                fc.update()
            o.animation_data.action = None
            tr = o.animation_data.nla_tracks.new()
            tr.name = clip
            st = tr.strips.new(clip, 0, act)
            st.extrapolation = 'NOTHING'
            tr.mute = True
            acts[name] = act
        self.apply({})
        return acts
