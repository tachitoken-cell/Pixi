"""Render a pose sheet: rows = models, columns = (clip, frame). Usage: ic_poses.py <blend> <out.png> <models,..> <clip:frame,..>"""
import math, sys, os
import bpy
from mathutils import Vector
from PIL import Image, ImageDraw
args = [a for a in sys.argv[1:] if not a.startswith("--")][-4:]
SRC, OUT, MODELS, SHOTS = args[0], args[1], args[2].split(","), [s.split(":") for s in args[3].split(",")]
bpy.ops.wm.open_mainfile(filepath=SRC)
sc = bpy.context.scene
sc.render.engine = 'CYCLES'; sc.cycles.device = 'CPU'; sc.cycles.samples = 12; sc.cycles.use_denoising = True
sc.render.resolution_x = sc.render.resolution_y = 300
sc.render.film_transparent = False
w = bpy.data.worlds.new("w"); sc.world = w; w.use_nodes = True; w.node_tree.nodes["Background"].inputs[0].default_value = (0.03, 0.03, 0.045, 1)
L = bpy.data.lights.new("sun", 'SUN'); L.energy = 3.5; lo = bpy.data.objects.new("sun", L); sc.collection.objects.link(lo); lo.rotation_euler = (0.8, 0.2, -0.6)
cam = bpy.data.cameras.new("c"); co = bpy.data.objects.new("c", cam); sc.collection.objects.link(co); sc.camera = co; cam.lens = 50
tmp = os.path.dirname(OUT) + "/_pose.png"
if bpy.data.collections.get("Skill FX"): bpy.data.collections["Skill FX"].hide_render = True
tiles = []
for m in MODELS:
    root = bpy.data.objects[m]
    parts = [o for o in root.children_recursive if o.animation_data]
    h = max(2.0, root.get("h", 0) or 0)
    row = []
    for clip, fr in SHOTS:
        for o in parts:
            for tr in o.animation_data.nla_tracks:
                tr.mute = tr.name != f"{m}-{clip}"
        sc.frame_set(int(fr))
        bpy.context.view_layer.update()
        pts = [o.matrix_world @ Vector(c) for o in parts for c in o.bound_box]
        lo_ = Vector([min(p[i] for p in pts) for i in range(3)]); hi = Vector([max(p[i] for p in pts) for i in range(3)])
        c = (lo_ + hi) / 2; size = max((hi - lo_).length, 2.5)
        d = Vector((0.55, -1, 0.35)).normalized()
        co.location = c + d * size * 1.25
        co.rotation_euler = (c - co.location).to_track_quat('-Z', 'Y').to_euler()
        sc.render.filepath = tmp
        bpy.ops.render.render(write_still=True)
        row.append(Image.open(tmp).copy())
    tiles.append(row)
W = 300
sheet = Image.new("RGB", (W * len(SHOTS), W * len(MODELS) + 24), (20, 20, 28))
dr = ImageDraw.Draw(sheet)
for j, (clip, fr) in enumerate(SHOTS):
    dr.text((j * W + 8, 6), f"{clip} f{fr}", fill=(220, 220, 220))
for i, row in enumerate(tiles):
    for j, im in enumerate(row):
        sheet.paste(im, (j * W, 24 + i * W))
    dr.text((8, 24 + i * W + 6), MODELS[i], fill=(255, 200, 120))
sheet.save(OUT)
print("ok", OUT)
