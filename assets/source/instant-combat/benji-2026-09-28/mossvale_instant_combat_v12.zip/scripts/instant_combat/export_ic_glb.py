"""Write the game GLB (drop-in replacement for public/models/instant-combat-monsters.glb).

Same settings as scripts/build-instant-combat-monsters.py: every root at identity, NLA tracks merged by name into
'<model>-<clip>' animations, Y-up, two shared materials. Adds '<boss>-skill-<slug>' clips. The 'Skill FX'
collection (telegraphs, dummies) is not exported. Usage: python3 export_ic_glb.py <animated.blend> <out.glb>
"""
import json, struct, sys
import bpy

SRC, OUT = [a for a in sys.argv[1:] if not a.startswith("--")][-2:]
bpy.ops.wm.open_mainfile(filepath=SRC)
scene = bpy.context.scene
scene.frame_set(0)
bpy.ops.object.select_all(action='DESELECT')
roots = [o for o in bpy.data.objects if o.parent is None and o.type == 'EMPTY' and "axes" in o]
expected = set()
for root in roots:
    root.location = (0, 0, 0)
    for o in [root, *root.children_recursive]:
        o.select_set(True)
        if o.animation_data:
            o.animation_data.action = None
            for tr in o.animation_data.nla_tracks:
                tr.mute = False
                expected.add(tr.name)
bpy.ops.export_scene.gltf(filepath=OUT, export_format='GLB', use_selection=True, export_yup=True, export_apply=True,
                          export_animations=True, export_animation_mode='NLA_TRACKS', export_merge_animation='NLA_TRACK',
                          export_force_sampling=False, export_cameras=False, export_lights=False, export_extras=True)
data = open(OUT, "rb").read()
length = struct.unpack_from('<I', data, 12)[0]
gltf = json.loads(data[20:20 + length])
names = {a['name'] for a in gltf.get('animations', [])}
assert names == expected, (sorted(names - expected), sorted(expected - names))
assert len(gltf['materials']) == 2, [m['name'] for m in gltf['materials']]
print(f"{OUT}: {len(names)} clips, {len(roots)} roots, {len(data) // 1024} KB")
