"""Instant Combat monsters: replace the near-static clips with lively ones and add 3 rule skills per boss.

Keeps your model roots, part names and clip names, lengths and contact frames (auto 30 f / hit 15, attack 48 f /
hit 24, idle 60, walk 36, death 60 at 30 fps), so monster-models.ts plays them unchanged. Adds per boss three
'<boss>-skill-<slug>' clips; their telegraphs, player dummies and rules live in the 'Skill FX' collection
(fx roots are not part of the monster roots, so the GLB export stays clean).

Usage: python3 ic_kit.py <instant-combat-monsters.blend> <out.blend>
"""
import math
import os
import sys

import bpy

sys.path.insert(0, os.path.dirname(__file__))
from ic_motion import BOSSES, SCEPTER, TAU, Rig, Track  # noqa: E402

SRC, OUT = [a for a in sys.argv[1:] if not a.startswith("--")][-2:]
bpy.ops.wm.open_mainfile(filepath=SRC)
scene = bpy.context.scene
scene.render.fps = 30

# ------------------------------------------------------------------ clean old clips
for o in bpy.data.objects:
    if o.animation_data:
        for tr in list(o.animation_data.nla_tracks):
            o.animation_data.nla_tracks.remove(tr)
        o.animation_data.action = None
for a in list(bpy.data.actions):
    bpy.data.actions.remove(a)

ROOTS = sorted([o for o in bpy.data.objects if o.parent is None and o.type == 'EMPTY' and o.name.replace("-", "").isalpha()],
               key=lambda o: o.name)
RIGS = {r.name: Rig(r) for r in ROOTS}


def base_keys(R, clip):
    h, kind, key = R.h, R.kind, R.key
    if clip in ("idle", "walk"):
        n = 60 if clip == "idle" else 36
        spin = TAU if clip == "idle" else TAU * 0.6
        return Track([(0, {"orbit.spin": 0, "halo.spin": 0}), (n, {"orbit.spin": spin, "halo.spin": -spin}, "lin")])
    if key in SCEPTER and clip in ("auto", "attack", "death"):
        return scepter_keys(R, clip)
    if clip == "auto":                                   # 30 f, contact on 15
        if kind == "biped":
            arm = "armL" if key == "marrow-colossus" else "armR"
            return Track([(0, {}), (9, {arm + ".rx": -1.5, "body.rz": 0.28 * (-1 if arm == "armL" else 1), "body.rx": -0.1, "head.rx": -0.1}),
                          (15, {arm + ".rx": 0.55, "body.rz": -0.22 * (-1 if arm == "armL" else 1), "body.rx": 0.16, "head.rx": 0.12}, "out"),
                          (20, {arm + ".rx": 0.4, "body.rz": -0.16 * (-1 if arm == "armL" else 1), "body.rx": 0.12}), (30, {})])
        if kind == "insect":
            return Track([(0, {}), (9, {"head.rx": -0.3, "body.y": 0.04 * h, "front.lift": 0.35, "body.rx": -0.1}),
                          (15, {"head.rx": 0.35, "body.y": -0.08 * h, "body.rx": 0.12, "front.lift": -0.1}, "out"),
                          (20, {"head.rx": 0.25, "body.y": -0.06 * h, "body.rx": 0.08}), (30, {})])
        if kind == "beast":
            return Track([(0, {}), (9, {"head.rx": -0.35, "body.y": 0.05 * h, "body.rx": -0.12, "tail.rx": 0.2}),
                          (15, {"head.rx": 0.32, "body.y": -0.1 * h, "body.rx": 0.12, "tail.rx": -0.1}, "out"),
                          (20, {"head.rx": 0.22, "body.y": -0.07 * h, "body.rx": 0.08}), (30, {})])
        if kind == "caster":
            return Track([(0, {"orbit.spin": 0, "halo.spin": 0}), (9, {"armR.rx": -1.0, "armL.rx": -0.3, "body.rx": -0.08, "head.rx": -0.12, "orbit.spin": -0.5}),
                          (15, {"armR.rx": 0.25, "armL.rx": 0.1, "body.rx": 0.14, "head.rx": 0.1, "orbit.spin": 1.6, "orbit.s": 0.12}, "out"),
                          (20, {"armR.rx": 0.15, "body.rx": 0.08, "orbit.spin": 2.2}), (30, {"orbit.spin": TAU, "halo.spin": 0})])
        return Track([(0, {}), (9, {"head.s": -0.08, "head.z": -0.05}), (15, {"head.s": 0.25, "head.z": 0.12, "head.rz": 1.0}, "out"), (30, {"head.rz": TAU})])
    if clip == "attack":                                 # 48 f, contact on 24
        if kind == "biped":
            wind = {"armR.rx": -2.5, "armL.rx": -2.5, "body.rx": -0.22, "body.z": 0.04 * h, "head.rx": -0.18, "stance": 0.1}
            hit = {"armR.rx": 0.65, "armL.rx": 0.65, "body.rx": 0.32, "body.z": -0.07 * h, "head.rx": 0.2, "stance": 0.22}
            return Track([(0, {}), (14, wind), (19, dict(wind, tremor=0.6)), (24, hit, "out"), (32, dict(hit, **{"body.rx": 0.28, "armR.rx": 0.55, "armL.rx": 0.55})),
                          (40, {"body.rx": -0.05, "armR.rx": -0.1, "armL.rx": -0.1}, "back"), (48, {})])
        if kind == "insect":
            wind = {"front.lift": 0.8, "body.rx": -0.42, "body.z": 0.1 * h, "head.rx": -0.35, "body.y": 0.05 * h}
            hit = {"front.lift": -0.25, "body.rx": 0.22, "body.z": -0.08 * h, "head.rx": 0.35, "body.y": -0.1 * h}
            return Track([(0, {}), (14, wind), (19, dict(wind, tremor=0.5)), (24, hit, "out"), (32, dict(hit, **{"body.rx": 0.18})), (48, {})])
        if kind == "beast":
            wind = {"front.lift": 0.9, "body.rx": -0.45, "body.z": 0.12 * h, "head.rx": -0.35, "tail.rx": 0.35}
            hit = {"front.lift": -0.15, "body.rx": 0.18, "body.z": -0.05 * h, "head.rx": 0.35, "tail.rx": -0.2, "body.y": -0.06 * h}
            return Track([(0, {}), (14, wind), (19, dict(wind, tremor=0.5)), (24, hit, "out"), (32, dict(hit, **{"body.rx": 0.14})), (48, {})])
        if kind == "caster":
            wind = {"armL.rx": -2.1, "armR.rx": -1.7, "body.rx": -0.16, "head.rx": -0.28, "orbit.s": 0.3, "halo.s": 0.3, "orbit.spin": -1.0, "body.z": 0.03 * h}
            hit = {"armL.rx": -0.5, "armR.rx": -0.25, "body.rx": 0.22, "head.rx": 0.15, "orbit.spin": 3.0, "orbit.s": -0.08, "halo.spin": 2.0}
            return Track([(0, {}), (14, wind), (19, dict(wind, tremor=0.5)), (24, hit, "out"), (32, dict(hit, **{"body.rx": 0.16, "orbit.spin": 4.2})),
                          (48, {"orbit.spin": TAU, "halo.spin": TAU})])
        return Track([(0, {}), (14, {"head.s": -0.12, "tremor": 0.4}), (24, {"head.s": 0.4, "head.z": 0.18, "head.rz": 2.0}, "out"), (48, {"head.rz": TAU})])
    # death, 60 f
    if kind == "biped":
        return Track([(0, {}), (8, {"body.rx": -0.28, "head.rx": -0.45, "armR.rx": -0.9, "armL.rx": -0.7, "tremor": 0.6}),
                      (20, {"body.rx": -0.08, "body.z": -0.16 * h, "stance": 0.3, "head.rx": 0.3, "armR.rx": -0.3, "armL.rx": -0.3}),
                      (42, {"body.rx": 1.45, "body.z": -0.35 * h, "armR.rx": -2.6, "armL.rx": -2.4, "head.rx": 0.4, "stance": 0.3}, "in"),
                      (48, {"body.rx": 1.36, "body.z": -0.33 * h, "armR.rx": -2.5, "armL.rx": -2.3, "head.rx": 0.2, "stance": 0.3}, "out"),
                      (60, {"body.rx": 1.4, "body.z": -0.34 * h, "armR.rx": -2.55, "armL.rx": -2.35, "head.rx": 0.3, "stance": 0.3})])
    if kind == "caster":
        return Track([(0, {}), (10, {"body.rx": -0.3, "head.rx": -0.5, "armL.rx": -2.0, "armR.rx": -1.8, "tremor": 0.8, "orbit.s": 0.25, "halo.s": 0.25}),
                      (26, {"body.rx": -0.1, "body.z": -0.1 * h, "head.rx": 0.3, "armL.rx": -0.6, "armR.rx": -0.5, "orbit.s": 0.1, "orbit.spin": 3}),
                      (46, {"body.rx": 1.25, "body.z": -0.4 * h, "body.sz": -0.2, "head.rx": 0.5, "armL.rx": -1.4, "armR.rx": -1.2, "orbit.s": -0.95, "halo.s": -0.95, "orbit.spin": 6}, "in"),
                      (60, {"body.rx": 1.2, "body.z": -0.42 * h, "body.sz": -0.22, "head.rx": 0.45, "armL.rx": -1.35, "armR.rx": -1.15, "orbit.s": -0.999, "halo.s": -0.999, "orbit.spin": 6})])
    if kind == "insect":
        return Track([(0, {}), (10, {"body.z": 0.08 * h, "legs.lift": 0.35, "body.rx": -0.25, "head.rx": -0.4, "tremor": 0.7}),
                      (34, {"body.z": -0.2 * h, "legs.splay": 0.7, "body.rz": 0.3, "body.ry": 0.25, "head.rx": 0.4}, "in"),
                      (44, {"body.z": -0.18 * h, "legs.splay": 0.5, "body.rz": 0.32, "body.ry": 0.22, "head.rx": 0.35}, "out"),
                      (60, {"body.z": -0.2 * h, "legs.lift": 0.9, "body.rz": 0.32, "body.ry": 0.25, "head.rx": 0.45})])
    if kind == "beast":
        return Track([(0, {}), (10, {"body.rx": -0.22, "head.rx": -0.55, "front.lift": 0.45, "tremor": 0.7, "tail.rx": 0.4}),
                      (40, {"body.ry": 1.35, "body.z": -0.25 * h, "head.rx": 0.35, "tail.rz": 0.8, "front.lift": 0.2}, "in"),
                      (48, {"body.ry": 1.28, "body.z": -0.24 * h, "head.rx": 0.25, "tail.rz": 0.7}, "out"),
                      (60, {"body.ry": 1.32, "body.z": -0.25 * h, "head.rx": 0.4, "tail.rz": 0.75})])
    return Track([(0, {}), (12, {"head.s": 0.2, "tremor": 1.0}), (40, {"head.s": -0.9, "head.z": -0.3, "body.sz": -0.55, "body.sx": 0.1, "head.rz": 3}, "in"),
                  (60, {"head.s": -0.999, "head.z": -0.35, "body.sz": -0.6, "body.sx": 0.12, "head.rz": 3})])


def scepter_keys(R, clip):
    """Grave / Void Cantor: every strike comes from the scepter (right arm), the body only leans into it."""
    h = R.h
    if clip == "auto":                                   # ranged (both cantors): charge the bolt on the scepter, thrust it out on 15
        return Track([(0, {}), (10, {"armR.rx": -0.7, "armR.rz": -0.15, "body.rx": -0.14, "body.z": 0.08, "head.rx": -0.2}),
                      (13, {"armR.rx": -0.75, "armR.rz": -0.15, "body.rx": -0.15, "body.z": 0.09, "head.rx": -0.22, "tremor": 0.5}),
                      (15, {"armR.rx": 1.0, "armR.rz": 0.05, "body.rx": 0.16, "body.z": 0.04, "head.rx": 0.12}, "out"),
                      (21, {"armR.rx": 0.8, "body.rx": 0.1}), (30, {})])
    if clip == "attack":                                 # 48 f, contact on 24: scepter raised high and trembling, then slammed forward
        wind = {"armR.rx": -0.9, "armR.rz": -0.15, "body.rx": -0.16, "body.z": 0.04 * h, "head.rx": -0.3, "halo.s": 0.3, "halo.spin": 1.5}
        hit = {"armR.rx": 1.15, "armR.rz": 0.05, "body.rx": 0.22, "body.z": -0.03 * h, "head.rx": 0.2, "halo.s": -0.05, "halo.spin": 4.5}
        return Track([(0, {"halo.spin": 0}), (14, wind), (19, dict(wind, tremor=0.5, **{"halo.spin": 3})), (24, hit, "out"),
                      (32, dict(hit, **{"armR.rx": 0.95, "body.rx": 0.18, "halo.spin": 5.2})), (40, {"armR.rx": -0.1, "halo.spin": 5.8}, "back"),
                      (48, {"halo.spin": TAU})])
    return Track([(0, {}), (10, {"body.rx": -0.3, "head.rx": -0.5, "armR.rx": -0.7, "tremor": 0.8, "halo.s": 0.25}),        # death: scepter drops first
                  (26, {"body.rx": -0.1, "body.z": -0.1 * h, "head.rx": 0.3, "armR.rx": 1.4, "halo.s": 0.1, "halo.spin": 3}),
                  (46, {"body.rx": 1.25, "body.z": -0.4 * h, "body.sz": -0.2, "head.rx": 0.5, "armR.rx": 1.6, "halo.s": -0.95, "halo.spin": 6}, "in"),
                  (60, {"body.rx": 1.2, "body.z": -0.42 * h, "body.sz": -0.22, "head.rx": 0.45, "armR.rx": 1.6, "halo.s": -0.999, "halo.spin": 6})])


CLIPS = (("idle", 60, True), ("walk", 36, True), ("auto", 30, False), ("attack", 48, False), ("death", 60, False))
for key, R in RIGS.items():
    for clip, n, loop in CLIPS:
        K = base_keys(R, clip)
        walk = clip == "walk" and R.kind != "object"
        fn = (lambda f, K=K, n=n, loop=loop, walk=walk, R=R, clip=clip:
              R.pose(K, f, n, loop, life=(0.0 if clip == "death" else 0.6 if walk else 1.0), gait_cycles=1 if walk else 0, gait_amp=1.0 if walk else 0.0))
        R.bake(f"{key}-{clip}", n, fn, loop, death=clip == "death")
    print("base clips", key)

if "--no-skills" not in sys.argv:
    import ic_skills  # noqa: E402
    ic_skills.build_all(RIGS, scene)

scene.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath=OUT)
print("saved", OUT)
